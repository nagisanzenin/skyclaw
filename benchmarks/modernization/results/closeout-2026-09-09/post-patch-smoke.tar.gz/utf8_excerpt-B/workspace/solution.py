"""Excerpt helper: longest prefix of text whose UTF-8 encoding fits a byte limit."""

__all__ = ["excerpt"]


def excerpt(text, limit):
    """Return the longest prefix of ``text`` whose UTF-8 bytes fit ``limit``.

    Characters are added from left to right; each character contributes the
    number of bytes its UTF-8 encoding occupies. Accumulation stops as soon
    as adding another character would exceed ``limit``.

    Args:
        text: The input string.
        limit: Maximum number of UTF-8 bytes allowed in the result. Must be
            a nonnegative integer.

    Returns:
        The longest character prefix of ``text`` fitting in ``limit`` bytes.

    Raises:
        ValueError: If ``limit`` is negative.
    """
    if limit < 0:
        raise ValueError("limit must be nonnegative")
    if limit == 0 or not text:
        return ""

    result = []
    used = 0
    for ch in text:
        w = len(ch.encode("utf-8"))
        if used + w > limit:
            break
        result.append(ch)
        used += w
    return "".join(result)
