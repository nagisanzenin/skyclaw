# Implement the requested API here.

import typing as t

Row = t.Dict[str, t.Any]


def page(
    rows: t.Iterable[Row],
    after: t.Optional[int],
    limit: int,
) -> t.Tuple[t.List[Row], t.Optional[int]]:
    """Cursor-paginate `rows` (dicts with a distinct integer 'id').

    - Raises ValueError if `limit` is not a positive integer.
    - Considers rows whose id is strictly greater than `after`
      (all rows when `after` is None), sorted by id ascending.
    - Returns at most `limit` of those rows plus a cursor: the id of the
      last returned row only if further eligible rows remain, else None.
    - Does not mutate the input.
    """
    if not isinstance(limit, int) or isinstance(limit, bool) or limit <= 0:
        raise ValueError("limit must be a positive integer")

    eligible = sorted(
        (row for row in rows if after is None or row["id"] > after),
        key=lambda row: row["id"],
    )

    selected = list(eligible[:limit])
    next_cursor = selected[-1]["id"] if len(eligible) > limit else None
    return selected, next_cursor
