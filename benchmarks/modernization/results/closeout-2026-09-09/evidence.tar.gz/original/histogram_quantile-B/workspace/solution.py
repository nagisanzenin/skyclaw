"""Quantile computation using the standard library only."""

import math
import numbers


def quantile(values, q):
    """Return the q-th quantile of *values* via linear interpolation.

    Raises ValueError if q is not in [0, 1] or not finite, or if values
    is empty or contains non-finite / non-numeric entries.
    """
    # Validate q.
    if isinstance(q, bool) or not isinstance(q, numbers.Real):
        raise ValueError("q must be a real number in [0, 1]")
    q = float(q)
    if not math.isfinite(q):
        raise ValueError("q must be finite")
    if not (0.0 <= q <= 1.0):
        raise ValueError("q must be in [0, 1]")

    # Validate values.
    if values is None:
        raise ValueError("values must be a non-empty sequence of finite numbers")
    try:
        n = len(values)
    except TypeError:
        raise ValueError("values must be a sequence of finite numbers")
    if n == 0:
        raise ValueError("values must be non-empty")

    clean = []
    for v in values:
        if isinstance(v, bool) or not isinstance(v, numbers.Real):
            raise ValueError("values must contain only real numbers")
        v = float(v)
        if not math.isfinite(v):
            raise ValueError("values must be finite")
        clean.append(v)

    # Sort a copy (clean is already a fresh list; the input is untouched).
    clean.sort()

    pos = (len(clean) - 1) * q
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return clean[lo]
    frac = pos - lo
    return clean[lo] + (clean[hi] - clean[lo]) * frac
