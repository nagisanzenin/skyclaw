"""Load INI configuration files into a merged dictionary."""

from configparser import ConfigParser


def load(paths):
    """Read INI files in order and return merged sections.

    - Interpolation is disabled (percent signs stay literal).
    - Returns a dict mapping each explicitly defined section name to a
      dict of its options, including values inherited from [DEFAULT].
    - Keys are lowercase; later files' values override earlier ones.
    - Missing files raise FileNotFoundError.
    """
    parser = ConfigParser(interpolation=None)

    for path in paths:
        with open(path, "r", encoding="utf-8") as fh:
            parser.read_file(fh)

    defaults = parser.defaults()
    result = {}
    for section in parser.sections():
        merged = dict(defaults)
        merged.update(parser[section])
        result[section] = merged
    return result
