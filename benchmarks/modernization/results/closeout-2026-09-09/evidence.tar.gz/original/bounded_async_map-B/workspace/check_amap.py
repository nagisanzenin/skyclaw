import asyncio
from solution import amap

async def main():
    # 1. Order preservation + concurrency cap
    active = peak = 0
    async def worker(x):
        nonlocal active, peak
        active += 1; peak = max(peak, active)
        await asyncio.sleep(0.01)
        active -= 1
        return x * 2
    res = await amap(worker, list(range(20)), 5)
    assert res == [x * 2 for x in range(20)], res
    assert peak == 5, peak
    print("OK order+limit: peak concurrency =", peak)

    # 2. Empty items
    assert await amap(worker, [], 3) == []
    print("OK empty items")

    # 3. limit <= 0 raises ValueError
    for bad in (0, -1):
        try:
            await amap(worker, [1], bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"expected ValueError for limit={bad}")
    print("OK ValueError for limit<=0")

    # 4. Failure: original exception re-raised, sleepers cancelled (finally runs)
    cancelled_seen = []
    async def sleeper(x):
        try:
            await asyncio.sleep(10)
        except asyncio.CancelledError:
            cancelled_seen.append(x)
            raise
    async def fail_0(x):
        if x == 0:
            raise RuntimeError("boom")
        await asyncio.sleep(0.05)
        return x
    try:
        await amap(fail_0, [0, 1, 2, 3], 4)
    except RuntimeError as e:
        assert str(e) == "boom"
    else:
        raise AssertionError("expected RuntimeError")
    await asyncio.sleep(0.05)
    assert sorted(cancelled_seen) == [1, 2, 3], cancelled_seen
    print("OK failure: 'boom' re-raised; cancelled sleepers:", sorted(cancelled_seen))

    # 5. No leaked pending tasks after failure
    assert not [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
    print("OK no leaked tasks")

    # 6. limit larger than len(items)
    assert await amap(worker, [1, 2, 3], 100) == [2, 4, 6]
    print("OK limit > len(items)")

    print("ALL CHECKS PASSED")

asyncio.run(main())
