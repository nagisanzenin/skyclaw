"""Async bounded-concurrency map using only the Python standard library."""

import asyncio
from typing import Any, Awaitable, Callable, Dict, List, Sequence


async def amap(
    fn: Callable[[Any], Awaitable[Any]],
    items: Sequence[Any],
    limit: int,
) -> List[Any]:
    """Apply async `fn` to each item in `items`, with at most `limit` calls
    active at once. Results are returned in the order of `items`.

    If any call raises, all outstanding tasks are cancelled and awaited, then
    the original exception is re-raised.
    """
    if limit <= 0:
        raise ValueError("limit must be a positive integer")

    items = list(items)
    results: List[Any] = [None] * len(items)
    if not items:
        return []

    next_index = 0
    index_of: Dict[asyncio.Future, int] = {}
    running = set()

    def _launch_ready() -> None:
        nonlocal next_index
        while len(running) < limit and next_index < len(items):
            i = next_index
            next_index += 1
            task = asyncio.ensure_future(fn(items[i]))
            index_of[task] = i
            running.add(task)

    try:
        _launch_ready()
        while running:
            done, running = await asyncio.wait(
                running, return_when=asyncio.FIRST_COMPLETED
            )
            for task in done:
                idx = index_of[task]
                if task.cancelled():
                    raise asyncio.CancelledError()
                exc = task.exception()
                if exc is not None:
                    raise exc
                results[idx] = task.result()
            _launch_ready()
    except BaseException:
        # Cancel all outstanding tasks and await their completion before
        # propagating the original failure.
        for task in running:
            task.cancel()
        if running:
            await asyncio.wait(running)
        raise

    return results
