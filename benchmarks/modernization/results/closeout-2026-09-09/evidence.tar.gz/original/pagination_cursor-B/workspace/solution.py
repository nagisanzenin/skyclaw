def page(rows, after, limit):
    """Return (selected, next_cursor).

    rows: list of dicts with distinct integer 'id' (unsorted, not mutated).
    after: None or integer cursor; only ids strictly greater than after.
    limit: must be a positive integer.
    """
    if not isinstance(limit, int) or isinstance(limit, bool) or limit <= 0:
        raise ValueError("limit must be a positive integer")

    selected = sorted(
        (row["id"] for row in rows if after is None or row["id"] > after)
    )[:limit]

    if len(selected) == limit and len(selected) == limit:
        # more eligible rows remain if there exists an id > selected[-1]
        next_cursor = selected[-1]
        for row in rows:
            if row["id"] > next_cursor:
                return selected, next_cursor
        return selected, None

    return selected, None
