"""Redact sensitive query parameters in a URL.

Uses only the Python standard library.
"""

from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

_REDACTED = "REDACTED"


def redact(url, sensitive):
    """Return *url* with values of sensitive query keys replaced by REDACTED.

    - Query pairs are parsed with blank values preserved (keep_blank_values).
    - A key matches if it equals (case-insensitively) one of the *sensitive*
      names; *sensitive* may be a single name or an iterable of names.
    - Pair order and repeated keys are preserved; non-sensitive values are
      kept as decoded by parse_qsl; path and fragment are untouched.
    - The query is re-encoded with urllib.parse.urlencode.
    """
    if isinstance(sensitive, str):
        sensitive = [sensitive]
    names = {str(name).lower() for name in sensitive}

    parts = urlsplit(url)
    pairs = parse_qsl(parts.query, keep_blank_values=True)
    redacted_pairs = [
        (key, _REDACTED if key.lower() in names else value)
        for key, value in pairs
    ]
    new_query = urlencode(redacted_pairs)
    return urlunsplit(
        (parts.scheme, parts.netloc, parts.path, new_query, parts.fragment)
    )
