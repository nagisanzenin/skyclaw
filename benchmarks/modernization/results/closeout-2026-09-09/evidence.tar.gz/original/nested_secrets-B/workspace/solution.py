"""Recursive scrubbing of sensitive keys from nested data structures."""

REDACTED = "[REDACTED]"


def _normalize_keys(keys):
    """Return a set of lowercased key names to redact."""
    if keys is None:
        return set()
    if isinstance(keys, str):
        keys = (keys,)
    try:
        iterator = iter(keys)
    except TypeError:
        return {str(keys).lower()}
    return {k.lower() for k in iterator if isinstance(k, str)}


def _scrub(value, redact_set):
    # Redacted dict: value under a case-insensitively matching key.
    if isinstance(value, dict):
        return {
            k: (REDACTED if isinstance(k, str) and k.lower() in redact_set
                else _scrub(v, redact_set))
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [_scrub(item, redact_set) for item in value]
    # Scalars (and other types) are immutable; returned as-is.
    return value


def scrub(value, keys):
    """Recursively copy dicts/lists, redacting values whose dict key
    matches one of ``keys`` case-insensitively with ``[REDACTED]``.

    The input is never modified, and no container is shared with it.
    """
    return _scrub(value, _normalize_keys(keys))
