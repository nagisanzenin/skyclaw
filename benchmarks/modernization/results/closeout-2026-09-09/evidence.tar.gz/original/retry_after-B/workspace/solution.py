import re
from datetime import datetime, timedelta
from email.utils import parsedate_to_datetime


_SECONDS_RE = re.compile(r"\A[0-9]+\Z")


def retry_after(value, now):
    """Return nonnegative float seconds until the Retry-After target.

    ``value`` may be a nonnegative decimal integer string (seconds) or an
    RFC HTTP date. ``now`` is a timezone-aware datetime. Returns 0.0 for
    past dates, None for invalid input.
    """
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    if not stripped:
        return None

    if _SECONDS_RE.match(stripped):
        target = now + timedelta(seconds=int(stripped))
        return max((target - now).total_seconds(), 0.0)

    try:
        target = parsedate_to_datetime(stripped)
    except (TypeError, ValueError):
        return None
    if not isinstance(target, datetime) or target.tzinfo is None:
        return None
    return max((target - now).total_seconds(), 0.0)
