"""Search the ``documents`` table for titles containing a literal fragment.

Only the Python standard library is used.
"""


def _escape_like(fragment: str) -> str:
    """Escape LIKE wildcards so % and _ are matched literally.

    Uses SQLite's ESCAPE clause with backslash as the escape character.
    """
    return fragment.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def search(conn, fragment):
    """Return (id, title) tuples whose title contains ``fragment``.

    Matching follows SQLite's case-insensitive LIKE semantics for ASCII
    characters. Percent (``%``) and underscore (``_``) inside ``fragment``
    are treated as literal characters, not wildcards. Results are ordered
    by ``id`` ascending.
    """
    pattern = "%" + _escape_like(fragment) + "%"
    cursor = conn.execute(
        "SELECT id, title FROM documents "
        "WHERE title LIKE ? ESCAPE '\\' "
        "ORDER BY id ASC",
        (pattern,),
    )
    return [(row[0], row[1]) for row in cursor.fetchall()]
