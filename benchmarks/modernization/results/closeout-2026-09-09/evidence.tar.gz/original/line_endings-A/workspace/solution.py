# Implement the requested API here.

"""normalize(data): normalize line endings in a byte string.

Rules:
- Input: ``bytes`` (a ``bytearray`` is also accepted for convenience).
- CRLF sequences (b"\\r\\n") and lone CR bytes (b"\\r") are replaced with LF
  (b"\\n").
- All other bytes are preserved verbatim, including bytes that are not valid
  UTF-8 (no decoding is ever performed).
- The operation is idempotent: normalize(normalize(x)) == normalize(x).
"""

_CRLF = b"\r\n"
_LF = b"\n"
_CR = b"\r"


def normalize(data):
    """Return ``data`` with CRLF and lone CR replaced by LF.

    Operates purely on bytes, so arbitrary binary content is preserved.
    """
    if data is None:
        raise TypeError("normalize() argument must be bytes, not None")
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError(
            "normalize() argument must be bytes or bytearray, not %s"
            % type(data).__name__
        )
    if len(data) == 0:
        return b""
    # Replace CRLF first so its CR is not turned into a lone LF-creating CR.
    out = bytes(data).replace(_CRLF, _LF)
    # Any remaining CR is a lone CR.
    return out.replace(_CR, _LF)
