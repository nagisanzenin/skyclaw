import random
from itertools import product
from solution import normalize

# Basic replacements
assert normalize(b"a\r\nb") == b"a\nb"
assert normalize(b"a\rb") == b"a\nb"
assert normalize(b"a\r\nb\rc\nd") == b"a\nb\nc\nd"
assert normalize(b"\r\n\r\n\r") == b"\n\n\n"
assert normalize(b"\r\r\n") == b"\n\n"

# No CR present: unchanged, including non-UTF8 bytes preserved
cases = [b"", b"abc", b"\x00\xff\xfe\x80",
         bytes(range(256)).replace(b"\r", b"")]
for c in cases:
    assert normalize(c) == c, c

# Non-UTF8 preserved around CRs
assert normalize(b"\xff\xfe\r\n\x80\r\x81") == b"\xff\xfe\n\x80\n\x81"

# Idempotency: exhaustive over all byte strings of length <= 3 over {LF, CR}
for n in range(4):
    for tup in product((b"\r", b"\n"), repeat=n):
        s = b"".join(tup)
        once = normalize(s)
        assert normalize(once) == once, (s, once)

# Idempotency + reference-correctness: random fuzz including non-UTF8
random.seed(42)
alphabet = b"\r\n\x00\xffA"
for _ in range(20000):
    s = bytes(random.choice(alphabet) for _ in range(random.randint(0, 24)))
    once = normalize(s)
    assert normalize(once) == once, s
    parts = s.split(b"\r\n")
    ref = b"\n".join(p.replace(b"\r", b"\n") for p in parts)
    assert once == ref, (s, once, ref)

# bytearray accepted; str rejected
assert normalize(bytearray(b"a\r\nb")) == b"a\nb"
try:
    normalize("a")
    raise SystemExit("FAIL: str accepted")
except TypeError:
    pass

print("ALL CHECKS PASSED")
