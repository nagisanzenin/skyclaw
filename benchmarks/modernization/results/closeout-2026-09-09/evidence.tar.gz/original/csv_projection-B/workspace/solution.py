import csv


def project(src, dst, columns):
    """Write a new CSV containing only `columns` (in the given order).

    Reads `src` as UTF-8 CSV with a header row, writes `dst` as UTF-8 CSV
    with a header row. Quoted commas/newlines inside cells are preserved
    by the csv module. Raises ValueError before touching `dst` if any
    requested column is missing from the source header.
    """
    with open(src, "r", encoding="utf-8", newline="") as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("source CSV is empty: no header row")
        index = {}
        for i, name in enumerate(header):
            index.setdefault(name, i)

        missing = [c for c in columns if c not in index]
        if missing:
            raise ValueError("missing column(s): %s" % ", ".join(missing))

        pick = [index[c] for c in columns]

        with open(dst, "w", encoding="utf-8", newline="") as out:
            writer = csv.writer(out)
            writer.writerow(columns)
            for row in reader:
                writer.writerow([row[i] if i < len(row) else "" for i in pick])
