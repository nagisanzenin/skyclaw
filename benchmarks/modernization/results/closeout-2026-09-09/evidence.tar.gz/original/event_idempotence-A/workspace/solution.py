# Implement the requested API here.
"""Event-application API using only the Python standard library."""


def apply(events):
    """Apply ledger events and return account balances.

    Each event is a dict with keys 'id', 'account' and 'delta' (int).

    Behaviour:
    - The first occurrence of each id is applied exactly once.
    - An exact duplicate of a previously seen id (same account and delta)
      is ignored.
    - A repeated id whose account or delta differs from its first
      occurrence raises ValueError.
    - The input list (and its event dicts) are not mutated.

    Returns a dict mapping account -> balance.
    """
    balances = {}
    seen = {}  # id -> (account, delta) of first occurrence

    for event in events:
        # Read-only access; never mutate the caller's dicts.
        event_id = event["id"]
        account = event["account"]
        delta = event["delta"]

        if event_id in seen:
            if seen[event_id] != (account, delta):
                raise ValueError(
                    "conflicting event for id %r: first seen as %r, got %r"
                    % (event_id, seen[event_id], (account, delta))
                )
            continue  # exact duplicate: ignore

        seen[event_id] = (account, delta)
        balances[account] = balances.get(account, 0) + delta

    return balances
