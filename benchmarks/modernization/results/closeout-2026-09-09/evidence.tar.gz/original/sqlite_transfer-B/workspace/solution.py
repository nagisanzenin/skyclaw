"""Atomic money transfer between accounts stored in SQLite.

The `accounts` table (id TEXT PRIMARY KEY, balance INTEGER) is assumed to
already exist on the passed connection. Only the Python standard library is
used.
"""

import sqlite3

__all__ = ["transfer"]


def _validate_amount(amount):
    # bool is a subclass of int, so reject it explicitly first.
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("amount must be a positive integer, got %r" % (amount,))
    if amount <= 0:
        raise ValueError("amount must be positive, got %r" % (amount,))


def _fetch_balance(conn, account_id):
    row = conn.execute(
        "SELECT balance FROM accounts WHERE id = ?", (account_id,)
    ).fetchone()
    if row is None:
        raise ValueError("account does not exist: %r" % (account_id,))
    return row[0]


def transfer(conn, source, destination, amount):
    """Atomically move `amount` from `source` to `destination`.

    Raises ValueError (leaving balances untouched) when:
      * amount is not a positive int (bools rejected),
      * source and destination are not distinct existing account IDs,
      * the source balance is insufficient.

    On success both updates are applied and committed atomically.
    """
    _validate_amount(amount)

    if source == destination:
        raise ValueError(
            "source and destination must be distinct, got %r" % (source,)
        )

    source_balance = _fetch_balance(conn, source)
    _fetch_balance(conn, destination)

    if source_balance < amount:
        raise ValueError(
            "insufficient funds in %r: balance=%r, requested=%r"
            % (source, source_balance, amount)
        )

    try:
        cursor = conn.execute(
            "UPDATE accounts SET balance = balance - ? "
            "WHERE id = ? AND balance >= ?",
            (amount, source, amount),
        )
        if cursor.rowcount != 1:
            raise ValueError(
                "insufficient funds in %r: balance=%r, requested=%r"
                % (source, source_balance, amount)
            )

        cursor = conn.execute(
            "UPDATE accounts SET balance = balance + ? WHERE id = ?",
            (amount, destination),
        )
        if cursor.rowcount != 1:
            raise ValueError("account does not exist: %r" % (destination,))

        conn.commit()
    except Exception:
        try:
            conn.rollback()
        except sqlite3.Error:
            pass
        raise
