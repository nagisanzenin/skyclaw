import random
import string
from solution import excerpt


def ref(text, limit):
    if limit < 0:
        raise ValueError
    n = 0
    for i, ch in enumerate(text):
        w = len(ch.encode("utf-8"))
        if n + w > limit:
            return text[:i]
        n += w
    return text


ok = True

cases = [
    ("", 0), ("", 10),
    ("hello", 0), ("hello", 4), ("hello", 5), ("hello", 100),
    ("hello world", 0), ("hello world", 10), ("hello world", 11),
    ("h\xe9llo w\xf6rld", 0), ("h\xe9llo w\xf6rld", 1), ("h\xe9llo w\xf6rld", 2), ("h\xe9llo w\xf6rld", 7),
    ("\u65e5\u672c\u8a9e", 0), ("\u65e5\u672c\u8a9e", 2), ("\u65e5\u672c\u8a9e", 3),
    ("\u65e5\u672c\u8a9e", 5), ("\u65e5\u672c\u8a9e", 9),
    ("emoji \U0001f600 here", 3), ("emoji \U0001f600 here", 4), ("emoji \U0001f600 here", 7),
    ("a b", 10),
]

for t, l in cases:
    got, exp = excerpt(t, l), ref(t, l)
    status = "OK  " if got == exp else "FAIL"
    if got != exp:
        ok = False
    print(f"{status} excerpt({t!r}, {l}) = {got!r} (expected {exp!r})")

pools = [string.ascii_letters, "\xe1\xe9\xee\xf6\xfc", "\u65e5\u672c\u8a9e",
         "\U0001f600\U0001f389\U0001f680", "a\xe9\u65e5\U0001f600", "\xe5 \u6f22"]
for trial in range(5000):
    t = "".join(random.choice(random.choice(pools)) for _ in range(random.randint(0, 12)))
    l = random.randint(0, 20)
    if excerpt(t, l) != ref(t, l):
        ok = False
        print("MISMATCH:", repr(t), l)
print("random cross-check: 5000 trials done")

for neg in (-1, -100):
    try:
        excerpt("abc", neg)
        print(f"FAIL: no error for limit={neg}")
        ok = False
    except ValueError as e:
        print(f"OK   ValueError raised for limit={neg}: {e}")

for t, l in cases:
    r = excerpt(t, l)
    assert isinstance(r, str) and t.startswith(r), (t, l)
    assert len(r.encode("utf-8")) <= l, (t, l)
    if len(r) < len(t):
        assert len(r.encode("utf-8")) + len(t[len(r)].encode("utf-8")) > l, (t, l)
print("prefix/byte-fit/maximality invariants hold")

print("ALL PASS" if ok else "SOME FAILURES")
