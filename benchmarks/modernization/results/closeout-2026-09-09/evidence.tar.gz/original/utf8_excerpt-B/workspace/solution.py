# Implement the requested API here.
def excerpt(text, limit):
    """Return the longest prefix of `text` (in Unicode characters) whose
    UTF-8 encoding fits within `limit` bytes.

    Raises ValueError if `limit` is negative.
    """
    if limit < 0:
        raise ValueError("limit must be nonnegative")
    total = 0
    for i, ch in enumerate(text):
        w = len(ch.encode("utf-8"))
        if total + w > limit:
            return text[:i]
        total += w
    return text
