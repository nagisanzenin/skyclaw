"""Quantile computation with linear interpolation (standard library only)."""

import math

__all__ = ["quantile"]


def _check_finite_number(x, what):
    """Return True if x is a finite real number (bool excluded)."""
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        raise ValueError(f"{what} must be a finite numeric value, got {x!r}")
    if isinstance(x, float) and not math.isfinite(x):
        raise ValueError(f"{what} must be a finite numeric value, got {x!r}")
    return True


def quantile(values, q):
    """Return the q-th quantile of *values* using linear interpolation.

    Parameters
    ----------
    values : iterable of finite real numbers (int/float, bool excluded).
             Must be non-empty, otherwise ValueError.
    q : float in [0, 1] and finite, otherwise ValueError.

    The index (n - 1) * q into the ascending-sorted copy of *values* is
    linearly interpolated between adjacent values. The input is never
    mutated.
    """
    _check_finite_number(q, "q")
    if not (0.0 <= q <= 1.0):
        raise ValueError(f"q must be in [0, 1], got {q!r}")

    data = list(values)
    if not data:
        raise ValueError("values must be non-empty")
    for i, v in enumerate(data):
        _check_finite_number(v, f"values[{i}]")

    data.sort()  # sorts the copy, original input is untouched

    n = len(data)
    pos = (n - 1) * q
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return data[int(pos)]
    fraction = pos - lo
    return data[lo] + (data[hi] - data[lo]) * fraction
