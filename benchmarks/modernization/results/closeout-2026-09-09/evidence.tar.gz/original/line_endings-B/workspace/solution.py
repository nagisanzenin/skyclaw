"""Normalize line endings in byte data.

normalize(data) converts CRLF ("\\r\\n") and lone CR ("\\r") to LF ("\\n"),
preserving every other byte exactly as-is (including non-UTF-8 bytes).
The operation is idempotent: normalize(normalize(x)) == normalize(x).
"""

_LINE_BREAKS = (b"\r\n", b"\r")


def normalize(data):
    """Return *data* with CRLF and lone CR replaced by LF.

    Parameters
    ----------
    data : bytes | bytearray | memoryview
        Input bytes. Bytearray/memoryview inputs are accepted and a
        plain ``bytes`` result is returned; the input is never mutated.

    Returns
    -------
    bytes
        New bytes object with normalized line endings. All other bytes,
        including invalid UTF-8 sequences, are preserved unchanged.

    Raises
    ------
    TypeError
        If *data* is not a bytes-like object.
    """
    if isinstance(data, (bytearray, memoryview)):
        data = bytes(data)
    if not isinstance(data, bytes):
        raise TypeError(
            "normalize() expects a bytes-like object, got %s" % type(data).__name__
        )

    # Order matters: collapse CRLF first so its CR is not turned into a
    # lone LF-producing break. After the second pass no b"\r" remains,
    # which makes the function idempotent.
    data = data.replace(b"\r\n", b"\n")
    data = data.replace(b"\r", b"\n")
    return data
