"""Bounded single-gzip-stream decompression using only the standard library."""

import zlib


def inflate(data, limit):
    """Decompress a single gzip byte stream.

    Returns the decompressed bytes only if their length is <= ``limit``
    (``limit`` must be a nonnegative int). At most ``limit + 1``
    uncompressed bytes are ever produced, so the decompression is bounded
    and never inflates the whole stream when it exceeds the limit.

    Raises:
        ValueError: if ``limit`` is negative, or the decompressed data
            would exceed ``limit``.
        OSError / EOFError: propagates from ``zlib`` for malformed,
            truncated, or otherwise invalid gzip input.
    """
    if limit < 0:
        raise ValueError("limit must be nonnegative")

    d = zlib.decompressobj(wbits=31)  # 31: gzip header/trailer handling
    remaining = limit + 1             # never read more than limit+1 bytes
    out = []

    pending = data
    while remaining > 0 and pending:
        chunk = d.decompress(pending, remaining)
        out.append(chunk)
        remaining -= len(chunk)
        pending = d.unconsumed_tail
        if not chunk:
            break

    result = b"".join(out)

    if len(result) > limit:
        raise ValueError("decompressed data exceeds limit")

    if not d.eof:
        if d.unconsumed_tail:
            # Output cap was hit mid-stream: data would exceed the limit.
            raise ValueError("decompressed data exceeds limit")
        raise EOFError("incomplete or truncated gzip stream")

    if d.unused_data:
        raise ValueError("trailing data after gzip stream")

    return result
