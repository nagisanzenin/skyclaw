import gzip
import zlib

import solution

# 1. Round-trip: valid gzip, exact bytes returned when size == limit and < limit
payload = b"hello world, gzip works!" * 10
blob = gzip.compress(payload)
assert solution.inflate(blob, len(payload)) == payload, "exact limit round-trip"
assert solution.inflate(blob, len(payload) + 5) == payload, "slack limit round-trip"

# 2. Exceeds limit -> ValueError, and it must not decompress the whole payload
big = bytes(1_000_000)
big_blob = gzip.compress(big)
try:
    solution.inflate(big_blob, 999_999)
    raise AssertionError("expected ValueError for limit below output size")
except ValueError as e:
    assert "exceed" in str(e), f"wrong ValueError: {e}"

# 3. Bounded read: limit+1 must be the hard cap, not unbounded decompression
small = gzip.compress(bytes(100))
assert len(small.inflate_read if False else solution.inflate(small, 99)) == 99
assert len(solution.inflate(small, 100)) == 100

# 4. Negative limit -> ValueError (checked before touching the stream)
for bad in (-1, -100):
    try:
        solution.inflate(blob, bad)
        raise AssertionError("expected ValueError for negative limit")
    except ValueError:
        pass

# 5. limit == 0 with nonempty stream -> ValueError
try:
    solution.inflate(blob, 0)
    raise AssertionError("expected ValueError for limit 0 on nonempty stream")
except ValueError:
    pass

# 6. limit == 0 with empty gzip stream -> b""
empty_blob = gzip.compress(b"")
assert solution.inflate(empty_blob, 0) == b""

# 7. Invalid gzip: truncated stream -> EOFError (spec: may propagate OSError/EOFError)
truncated = big_blob[: len(big_blob) // 2]
try:
    solution.inflate(truncated, 10**9)
    raise AssertionError("expected error for truncated gzip")
except (OSError, EOFError):
    pass

# 8. Invalid gzip: corrupt header/garbage -> OSError (zlib.error is a subclass)
try:
    solution.inflate(b"not gzip at all", 10**9)
    raise AssertionError("expected error for garbage input")
except (OSError, EOFError):
    pass

# 9. Multi-stream / trailing garbage -> ValueError (single-stream contract)
two = gzip.compress(b"a") + gzip.compress(b"b")
try:
    solution.inflate(two, 10**9)
    raise AssertionError("expected ValueError for multi-stream input")
except ValueError:
    pass

print("all inflate checks passed")
