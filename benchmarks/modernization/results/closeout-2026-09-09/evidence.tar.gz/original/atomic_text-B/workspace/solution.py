"""Atomic file writing using only the Python standard library."""

import os
import tempfile
from pathlib import Path


def write_atomic(path, text):
    """Write *text* to *path* atomically.

    The text is written (UTF-8) to a temporary file in the same directory,
    flushed and fsynced, then moved into place with os.replace. If anything
    fails, the original destination is left untouched and the temporary
    file is removed.

    :param path: destination path (str or pathlib.Path)
    :param text: str content to write
    """
    dest = Path(path)
    fd, tmp_name = tempfile.mkstemp(
        dir=str(dest.parent), prefix="." + dest.name + ".", suffix=".tmp"
    )
    tmp_path = Path(tmp_name)
    try:
        with open(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_path, dest)
    except BaseException:
        try:
            tmp_path.unlink()
        except OSError:
            pass
        raise
