"""Weighted arithmetic mean of (value, weight) pairs."""

import math

__all__ = ["mean"]


def mean(pairs):
    """Return the weighted arithmetic mean of ``(value, weight)`` pairs.

    Parameters
    ----------
    pairs : iterable of (value, weight)
        Both elements must be finite real numbers; weights must be >= 0.

    Returns
    -------
    float
        sum(value * weight) / sum(weight).

    Raises
    ------
    ValueError
        If any pair is malformed, contains a non-finite/non-numeric value,
        or has a negative weight; or if the input is empty or the total
        weight is zero.
    """
    if pairs is None:
        raise ValueError("pairs must be an iterable of (value, weight) tuples")

    try:
        items = list(pairs)
    except TypeError:
        raise ValueError("pairs must be an iterable of (value, weight) tuples")

    if not items:
        raise ValueError("pairs must not be empty")

    total_weight = 0.0
    weighted_sum = 0.0

    for index, pair in enumerate(items):
        if isinstance(pair, (set, frozenset, dict, str, bytes)):
            raise ValueError(
                "item %d is not a (value, weight) pair of length 2" % index
            )
        try:
            if len(pair) != 2:
                raise ValueError
            value, weight = pair
        except (TypeError, ValueError):
            raise ValueError(
                "item %d is not a (value, weight) pair of length 2" % index
            )

        # Reject booleans explicitly: bool is a subclass of int but not a
        # meaningful numeric weight/value here.
        for label, x in (("value", value), ("weight", weight)):
            if isinstance(x, bool) or not isinstance(x, (int, float)):
                raise ValueError(
                    "item %d has a non-numeric %s: %r" % (index, label, x)
                )

        value = float(value)
        weight = float(weight)

        if not math.isfinite(value):
            raise ValueError("item %d has a non-finite value" % index)
        if not math.isfinite(weight):
            raise ValueError("item %d has a non-finite weight" % index)
        if weight < 0:
            raise ValueError("item %d has a negative weight" % index)

        total_weight += weight
        weighted_sum += value * weight

    if total_weight == 0:
        raise ValueError("total weight must be positive, got zero")

    result = weighted_sum / total_weight
    if not math.isfinite(result):
        raise ValueError("weighted mean is not finite")
    return result
