"""Redact sensitive query-string values in a URL.

Public API: redact(url, sensitive) -> str
"""

from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

_REDACTED = "REDACTED"


def redact(url, sensitive):
    """Return *url* with values of sensitive query keys replaced by REDACTED.

    - Query pairs are parsed with blank values preserved.
    - A key is sensitive if it matches (case-insensitively) any name in
      *sensitive* (an iterable of names).
    - Pair order, repeated keys, other decoded values, the path and the
      fragment are preserved. The query is re-encoded via urlencode.
    """
    sensitive_lower = {str(name).lower() for name in sensitive}

    parts = urlsplit(url)
    pairs = parse_qsl(parts.query, keep_blank_values=True)

    redacted_pairs = [
        (key, _REDACTED if key.lower() in sensitive_lower else value)
        for key, value in pairs
    ]

    new_query = urlencode(redacted_pairs)
    return urlunsplit(
        (parts.scheme, parts.netloc, parts.path, new_query, parts.fragment)
    )
