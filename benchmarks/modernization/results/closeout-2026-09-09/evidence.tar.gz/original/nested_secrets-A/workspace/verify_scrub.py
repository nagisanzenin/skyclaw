import copy
from solution import scrub

failures = []


def check(name, cond, detail=""):
    if cond:
        print(f"PASS: {name}")
    else:
        failures.append(name)
        print(f"FAIL: {name} {detail}")


# 1. Case-insensitive key matching
src = {"Name": "x", "PASSWORD": "secret", "pasSwoRd2": "y"}
out = scrub(src, ["name", "password", "password2"])
check("case-insensitive redaction", out == {"Name": "[REDACTED]", "PASSWORD": "[REDACTED]", "pasSwoRd2": "[REDACTED]"}, repr(out))
check("input not mutated", src == {"Name": "x", "PASSWORD": "secret", "pasSwoRd2": "y"})

# 2. Nested dicts and lists (inner key differs from outer)
nested = {"a": 1, "acct": {"user": "bob", "n": [1, {"token": "t", "ok": True}]}}
out2 = scrub(nested, ["user", "token"])
expected2 = {"a": 1, "acct": {"user": "[REDACTED]", "n": [1, {"token": "[REDACTED]", "ok": True}]}}
check("nested dict/list recursion", out2 == expected2, repr(out2))
check("nested input not mutated", nested == {"a": 1, "acct": {"user": "bob", "n": [1, {"token": "t", "ok": True}]}})

# 3. Scalars unchanged / passthrough at top level
scalars = [None, True, False, 0, 3.14, "txt", b"bytes", (1, 2), 10**20]
check("top-level scalar passthrough", scrub(scalars, ["a"]) == scalars)
check("scalar identity preserved", all(scrub(scalars, ["a"])[i] is scalars[i] for i in range(len(scalars))))
check("non-container passthrough", scrub(42, ["k"]) == 42)

# 4. Non-string keys never match string keys list
nk = {1: "keep", ("t",): "keep", None: "keep"}
check("non-string keys untouched", scrub(nk, ["1", "t"]) == nk, repr(scrub(nk, ["1", "t"])))

# 5. Deep independence: mutate output, input unchanged
orig = {"cfg": {"secret": "s", "items": [{"pw": "p"}]}, "other": [1, 2]}
snapshot = copy.deepcopy(orig)
res = scrub(orig, ["secret", "pw"])
res["cfg"]["items"][0]["pw"] = "CHANGED"
res["cfg"]["items"].append("extra")
res["other"].append(99)
check("output mutation does not affect input", orig == snapshot)

# 6. No shared mutable containers between input and output
shared = [
    res["cfg"] is orig["cfg"],
    res["cfg"]["items"] is orig["cfg"]["items"],
    res["cfg"]["items"][0] is orig["cfg"]["items"][0],
    res["other"] is orig["other"],
]
check("no shared dict/list containers", not any(shared), repr(shared))

# 7. Input deep-equal to snapshot after all mutations
check("input unchanged after all mutations", orig == snapshot)

# 8. Empty keys -> faithful deep copy, independent
out3 = scrub({"a": {"b": [1]}}, [])
check("empty keys deep copy equal", out3 == {"a": {"b": [1]}})
check("empty keys no container sharing", out3["a"] is not None and out3["a"]["b"] is not None)
src3 = {"a": {"b": [1]}}
o3 = scrub(src3, [])
o3["a"]["b"].append(2)
check("empty keys input intact", src3 == {"a": {"b": [1]}})

# 9. Redaction sentinel value is exactly the string "[REDACTED]"
res_v = scrub({"password": "x"}, ["password"])
check("redaction sentinel value", res_v["password"] == "[REDACTED]" and isinstance(res_v["password"], str))

print()
print("RESULT:", "ALL PASS" if not failures else f"{len(failures)} FAILURES: {failures}")
raise SystemExit(0 if not failures else 1)
