"""Recursively scrub sensitive values from nested dict/list structures.

Standard library only.
"""

_REDACTED = "[REDACTED]"


def _normalize(key):
    """Lowercased string form of a dict key, for case-insensitive matching."""
    return key.lower() if isinstance(key, str) else key


def scrub(value, keys):
    """Return a deep copy of *value* with sensitive dict values redacted.

    Recursively copies dict and list containers. Any dict value whose key
    matches one of *keys* (string comparison, case-insensitive) is replaced
    with the string "[REDACTED]". All other values are copied unchanged.
    The input structure is never mutated, and no mutable container is shared
    between the input and the returned structure.
    """
    redact = {_normalize(k) for k in keys}

    def _scrub(node):
        if isinstance(node, dict):
            out = {}
            for k, v in node.items():
                if _normalize(k) in redact:
                    out[k] = _REDACTED
                else:
                    out[k] = _scrub(v)
            return out
        if isinstance(node, list):
            return [_scrub(item) for item in node]
        return node

    return _scrub(value)
