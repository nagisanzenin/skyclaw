"""Atomic file writing using only the Python standard library."""

import os
import tempfile
from pathlib import Path


def write_atomic(path, text):
    """Write *text* to *path* atomically.

    The text is encoded as UTF-8 and written to a temporary file in the
    destination's directory (a sibling), which is then flushed and fsync'd
    before replacing the destination via ``os.replace``.

    On any failure the original destination is left untouched and the
    temporary file is removed.

    Args:
        path: Destination file path (``pathlib.Path`` or anything
            ``Path()`` accepts).
        text: String content to write.

    Raises:
        Whatever the underlying write/replace operations raise; the
        destination remains unchanged in that case.
    """
    dest = Path(path)
    fd = None
    tmp_path = None
    try:
        # Temporary sibling: same directory guarantees os.replace works
        # atomically on the same filesystem.
        fd, tmp_name = tempfile.mkstemp(
            dir=dest.parent, prefix="." + dest.name + ".", suffix=".tmp"
        )
        tmp_path = Path(tmp_name)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            fd = None  # ownership transferred to the file object
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, dest)
        tmp_path = None  # replaced successfully; nothing to clean up
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
        if tmp_path is not None:
            try:
                tmp_path.unlink()
            except FileNotFoundError:
                pass
