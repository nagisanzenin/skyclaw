"""Tests for write_atomic in solution.py (temporary file, removed after run)."""
import os
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from solution import write_atomic

failures = []

def check(name, cond, detail=""):
    if cond:
        print(f"PASS: {name}")
    else:
        failures.append(name)
        print(f"FAIL: {name} {detail}")

tmp = Path(tempfile.mkdtemp(prefix="wa_test_"))
try:
    # 1. Successful write creates destination with exact UTF-8 content.
    dest = tmp / "out.txt"
    write_atomic(dest, "héllo wörld ✓")
    got = dest.read_text(encoding="utf-8")
    check("success writes exact UTF-8 content", got == "héllo wörld ✓", repr(got))

    # 2. No leftover temp files after success.
    leftovers = [p.name for p in tmp.iterdir() if p.name != "out.txt"]
    check("no temp files left after success", leftovers == [], leftovers)

    # 3. Accepts str-convertible and overwrites existing content.
    write_atomic(dest, "second")
    check("overwrite existing destination",
          dest.read_text(encoding="utf-8") == "second")

    # 4. Failure preserves old destination and removes temp file.
    #    Force failure inside the write phase: make a read-only temp target by
    #    patching os.replace to raise on first call.
    dest.write_text("original", encoding="utf-8")
    real_replace = os.replace
    calls = {"n": 0}

    def boom(src, dst):
        calls["n"] += 1
        raise OSError("simulated replace failure")

    os.replace = boom
    try:
        write_atomic(dest, "new content")
        check("failure raises to caller", False, "no exception raised")
    except OSError:
        check("failure raises to caller", True)
    finally:
        os.replace = real_replace

    check("old destination preserved on failure",
          dest.read_text(encoding="utf-8") == "original")
    leftovers = [p.name for p in tmp.iterdir() if p.name != "out.txt"]
    check("temp file removed after failure", leftovers == [], leftovers)

    # 5. fsync actually invoked on the temp file (monkeypatch counter).
    import solution
    real_fsync = os.fsync
    fsync_calls = []
    def spy_fsync(fd):
        fsync_calls.append(fd)
        return real_fsync(fd)
    os.fsync = spy_fsync
    try:
        write_atomic(dest, "synced")
    finally:
        os.fsync = real_fsync
    check("os.fsync called during write", len(fsync_calls) == 1,
          f"calls={len(fsync_calls)}")
    check("content correct after fsync check",
          dest.read_text(encoding="utf-8") == "synced")

    # 6. Failure during the write phase (UnicodeEncodeError never happens for
    #    str, so simulate a disk error via a full-path directory removal).
    dest.write_text("keep me", encoding="utf-8")
    # Force mkstemp to fail by pointing at a path whose parent is a file.
    bad = tmp / "notadir"
    bad.write_text("x", encoding="utf-8")
    try:
        write_atomic(bad / "f.txt", "data")
        check("mkstemp failure raises", False, "no exception raised")
    except (OSError, NotADirectoryError):
        check("mkstemp failure raises", True)
    check("destination untouched when mkstemp fails",
          bad.read_text(encoding="utf-8") == "x")

    # 7. Accepts pathlib.Path explicitly and works in a fresh subdir.
    sub = tmp / "sub"
    sub.mkdir()
    p = sub / Path("nested.bin")
    write_atomic(p, "\u00e9\n")
    check("pathlib.Path accepted", p.read_text(encoding="utf-8") == "\u00e9\n")

    # 8. Temp file is a sibling (same directory) — verify via monkeypatching
    #    mkstemp capture is complex; instead verify replace target dir.
    check("destination dir unchanged listing",
          sorted(q.name for q in sub.iterdir()) == ["nested.bin"])
finally:
    shutil.rmtree(tmp, ignore_errors=True)

print()
if failures:
    print(f"RESULT: {len(failures)} FAILED -> {failures}")
    sys.exit(1)
print("RESULT: ALL TESTS PASSED")
