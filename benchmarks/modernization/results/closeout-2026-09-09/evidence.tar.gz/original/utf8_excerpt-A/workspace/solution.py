"""excerpt: longest Unicode character prefix whose UTF-8 bytes fit a byte limit.

Standard library only.
"""


def excerpt(text: str, limit: int) -> str:
    """Return the longest prefix of ``text`` whose UTF-8 encoding fits ``limit`` bytes.

    Args:
        text: The input string (any Unicode content).
        limit: Maximum number of UTF-8 bytes allowed in the result.
            Must be a nonnegative integer.

    Returns:
        The longest prefix of ``text`` (cut only at Unicode character
        boundaries) whose UTF-8 encoding is at most ``limit`` bytes long.

    Raises:
        ValueError: If ``limit`` is negative.
    """
    if limit < 0:
        raise ValueError("limit must be a nonnegative integer, got %r" % (limit,))

    encoded = text.encode("utf-8")
    if len(encoded) <= limit:
        return text

    truncated = encoded[:limit]

    # Find the last byte that is NOT a continuation byte (i.e. a lead byte
    # or plain ASCII). Everything after it is trailing continuation bytes.
    i = len(truncated) - 1
    while i >= 0 and (truncated[i] & 0xC0) == 0x80:
        i -= 1

    if i < 0:
        # Cannot happen for valid UTF-8 (first byte is always a lead byte).
        return ""

    lead = truncated[i]
    if lead & 0x80 == 0:
        charlen = 1
    elif lead & 0xE0 == 0xC0:
        charlen = 2
    elif lead & 0xF0 == 0xE0:
        charlen = 3
    elif lead & 0xF8 == 0xF0:
        charlen = 4
    else:  # invalid lead byte; cannot occur in valid UTF-8
        charlen = 1

    if i + charlen <= len(truncated):
        # The final character's sequence is complete: everything fits.
        return truncated.decode("utf-8")
    # The final character was cut mid-sequence: drop its lead byte.
    return truncated[:i].decode("utf-8")


__all__ = ["excerpt"]
