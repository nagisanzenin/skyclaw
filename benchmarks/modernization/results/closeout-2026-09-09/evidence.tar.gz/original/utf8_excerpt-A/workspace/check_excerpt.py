import sys

from solution import excerpt

failures = []


def check(desc, got, want):
    if got != want:
        failures.append(f"{desc}: got {got!r}, want {want!r}")


def check_raises(desc, fn):
    try:
        fn()
    except ValueError:
        return
    except Exception as e:  # noqa: BLE001
        failures.append(f"{desc}: raised {type(e).__name__} instead of ValueError")
        return
    failures.append(f"{desc}: did not raise ValueError")


# --- Negative limits ---
for neg in (-1, -5, -1000):
    check_raises(f"limit={neg}", lambda n=neg: excerpt("hello", n))
check_raises("negative limit on empty text", lambda: excerpt("", -1))

# --- ASCII ---
check("ascii full fit", excerpt("hello", 5), "hello")
check("ascii exact cut", excerpt("hello", 3), "hel")
check("ascii limit 0", excerpt("hello", 0), "")
check("ascii empty text", excerpt("", 0), "")
check("ascii empty text big limit", excerpt("", 10), "")
check("ascii limit over length", excerpt("hi", 100), "hi")

# --- Multibyte (2-byte: é, 3-byte: €, 4-byte: emoji) ---
check("2-byte char full", excerpt("é", 2), "é")
check("2-byte char cut mid", excerpt("é", 1), "")
check("3-byte char full", excerpt("€", 3), "€")
check("3-byte char cut mid", excerpt("€", 2), "")
check("3-byte char cut mid-1", excerpt("€", 1), "")
check("4-byte emoji full", excerpt("\U0001F600", 4), "\U0001F600")
check("4-byte emoji cut 3", excerpt("\U0001F600", 3), "")
check("4-byte emoji cut 1", excerpt("\U0001F600", 1), "")
check("mixed exact boundary", excerpt("aé€\U0001F600", 1 + 2 + 3), "aé€")
check("mixed cut inside emoji", excerpt("aé€\U0001F600", 1 + 2 + 3 + 2), "aé€")
check("mixed cut inside euro", excerpt("aé€", 3), "aé")

# --- Brute-force reference check on arbitrary text ---
ref_text = "héllo € wörld \U0001F600 café ñ"
encoded = ref_text.encode("utf-8")
max_len = len(excerpt(ref_text, 10**9)).__str__()  # sanity: whole string returned
check("whole string when limit huge", excerpt(ref_text, len(encoded)), ref_text)
for lim in range(0, len(encoded) + 3):
    got = excerpt(ref_text, lim)
    # Property 1: result fits in limit bytes
    if len(got.encode("utf-8")) > lim:
        failures.append(f"limit={lim}: result exceeds byte limit")
    # Property 2: result is a prefix
    if not ref_text.startswith(got):
        failures.append(f"limit={lim}: result is not a prefix")
    # Property 3: maximality — can't add one more char and still fit
    if got != ref_text:
        nxt = ref_text[: len(got) + 1]
        if len(nxt.encode("utf-8")) <= lim:
            failures.append(f"limit={lim}: prefix not maximal, could include {nxt!r}")

# --- Non-integer limits: observe behavior (documented, not specified) ---
try:
    excerpt("abc", 2.5)
    print("NOTE: float limit 2.5 accepted (spec silent on non-int)")
except Exception as e:  # noqa: BLE001
    print(f"NOTE: float limit 2.5 raises {type(e).__name__}")

if failures:
    print(f"FAILED ({len(failures)}):")
    for f in failures:
        print("  -", f)
    sys.exit(1)
print("ALL CHECKS PASSED")
