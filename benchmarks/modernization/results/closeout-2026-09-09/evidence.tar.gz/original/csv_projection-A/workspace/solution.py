"""project(src, dst, columns): select columns from a UTF-8 CSV into a new UTF-8 CSV.

Standard library only. Quoted commas/newlines inside cell values are preserved.
A missing requested column raises ValueError before dst is opened or written.
"""

import csv


def project(src, dst, columns):
    """Read CSV at *src* (UTF-8, with header) and write CSV at *dst* (UTF-8)
    containing only *columns*, in the requested order, header included.

    Raises:
        ValueError: if any requested column is absent from the source header.
                    Raised before *dst* is opened or written.
    """
    columns = list(columns)
    if not columns:
        raise ValueError("no columns requested")

    with open(src, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        if fieldnames is None:
            raise ValueError("source CSV has no header row")
        missing = [c for c in columns if c not in fieldnames]
        if missing:
            raise ValueError("missing column(s): %s" % ", ".join(missing))
        rows = list(reader)

    with open(dst, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore",
                                lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({c: row[c] for c in columns})
