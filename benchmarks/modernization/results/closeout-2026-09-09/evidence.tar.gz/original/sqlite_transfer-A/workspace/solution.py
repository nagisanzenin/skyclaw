"""Atomic SQLite money transfer between two accounts.

Schema: accounts(id TEXT PRIMARY KEY, balance INTEGER)
Only the Python standard library is used.
"""

import sqlite3


def transfer(conn, source, destination, amount):
    """Atomically move ``amount`` from ``source`` to ``destination``.

    Rules:
      * ``source`` and ``destination`` must be distinct, existing account IDs.
      * ``amount`` must be a positive integer (``bool`` is rejected).
      * ``source`` must hold at least ``amount`` funds.
      * Any violation raises :class:`ValueError` with no balance change.

    Assumes no transaction is active on entry.
    """
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("amount must be a positive integer")
    if amount <= 0:
        raise ValueError("amount must be a positive integer")
    if source == destination:
        raise ValueError("source and destination must be distinct")
    if not isinstance(source, str) or not isinstance(destination, str):
        raise ValueError("source and destination must be account ID strings")

    # Single connection: assume no transaction active on entry, so the whole
    # check-then-apply sequence below runs inside one implicit transaction,
    # making it atomic on commit or rollback.
    cur = conn.execute(
        "SELECT balance FROM accounts WHERE id = ?", (source,)
    ).fetchone()
    src_balance = cur[0] if cur is not None else None

    dst_row = conn.execute(
        "SELECT balance FROM accounts WHERE id = ?", (destination,)
    ).fetchone()
    dst_exists = dst_row is not None

    if src_balance is None:
        raise ValueError("source account does not exist: %r" % (source,))
    if not dst_exists:
        raise ValueError(
            "destination account does not exist: %r" % (destination,)
        )
    if src_balance < amount:
        raise ValueError(
            "insufficient funds in source account %r: have %d, need %d"
            % (source, src_balance, amount)
        )

    conn.execute(
        "UPDATE accounts SET balance = balance - ? WHERE id = ?",
        (amount, source),
    )
    conn.execute(
        "UPDATE accounts SET balance = balance + ? WHERE id = ?",
        (amount, destination),
    )
    conn.commit()
