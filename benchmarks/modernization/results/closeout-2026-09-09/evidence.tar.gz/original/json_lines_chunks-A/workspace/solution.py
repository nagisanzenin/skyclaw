"""UTF-8 JSON Lines parsing over arbitrary byte chunks.

Public API: parse_chunks(chunks) -> list of parsed JSON values.
Only the Python standard library is used.
"""

import codecs
import json


def parse_chunks(chunks):
    """Parse UTF-8 JSON Lines supplied as an iterable of byte chunks.

    - Decodes incrementally, so multi-byte UTF-8 sequences split across
      chunk boundaries are handled correctly.
    - Blank lines (empty or whitespace-only) are ignored.
    - A final record not terminated by a newline is still parsed.
    - Malformed JSON or invalid UTF-8 raises ValueError
      (UnicodeDecodeError is a subclass of ValueError).

    Returns a list of the parsed values in input order.
    """
    decoder = codecs.getincrementaldecoder("utf-8")()
    values = []
    buffer = ""

    for chunk in chunks:
        if chunk:
            buffer += decoder.decode(chunk)

        # Process all complete lines currently available.
        while True:
            newline_pos = buffer.find("\n")
            if newline_pos == -1:
                break
            line = buffer[:newline_pos]
            buffer = buffer[newline_pos + 1:]
            _parse_line(line, values)

    # Flush any pending partial multi-byte sequence; raises
    # UnicodeDecodeError if the stream ends mid-character.
    buffer += decoder.decode(b"", final=True)

    # Final record without a trailing newline.
    _parse_line(buffer, values)
    return values


def _parse_line(line, values):
    """Parse one logical line, ignoring blank lines; append parsed value."""
    if not line.strip():
        return
    values.append(json.loads(line))
