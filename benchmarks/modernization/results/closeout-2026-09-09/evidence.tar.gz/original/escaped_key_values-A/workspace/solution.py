"""Parse simple key=value text into a dict."""


def parse(text):
    """Parse ``text`` containing one ``key=value`` per nonblank line.

    - Lines are split only at the first ``=``.
    - Keys and values have surrounding whitespace stripped.
    - Lines whose stripped form starts with ``#`` are ignored (comments),
      as are blank/whitespace-only lines.
    - Raises ValueError for noncomment lines without ``=``,
      empty keys, or duplicate keys.
    """
    result = {}
    for raw_line in str(text).splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise ValueError(
                "invalid line (missing '='): %r" % raw_line
            )
        key, _, value = line.partition("=")
        key = key.strip()
        if not key:
            raise ValueError("empty key in line: %r" % raw_line)
        if key in result:
            raise ValueError("duplicate key: %r" % key)
        result[key] = value.strip()
    return result
