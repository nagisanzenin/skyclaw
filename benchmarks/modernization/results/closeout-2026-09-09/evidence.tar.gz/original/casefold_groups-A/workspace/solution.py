"""Group strings by their Unicode casefold key.

Public API:
    groups(words) -> list[list[str]]
"""

from collections import OrderedDict


def groups(words):
    """Group strings by their Unicode casefold key.

    Groups appear in the order each casefold key is first encountered, and
    words within each group keep their original relative order. Duplicates
    are retained. The input sequence is not mutated.

    Args:
        words: An iterable of strings.

    Returns:
        A list of lists of strings, where each inner list contains all
        words sharing one casefold key.
    """
    index = OrderedDict()
    for word in words:
        key = word.casefold()
        index.setdefault(key, []).append(word)
    return list(index.values())
