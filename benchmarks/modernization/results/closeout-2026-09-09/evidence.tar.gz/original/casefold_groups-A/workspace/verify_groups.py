import ast
import copy
import sys

sys.path.insert(0, ".")
import solution

# 1. groups exists and is callable
assert callable(solution.groups), "groups not callable"

# 2. Basic casefold grouping
assert solution.groups(["Apple", "apple", "APPLE", "Banana"]) == [
    ["Apple", "apple", "APPLE"],
    ["Banana"],
]

# 3. First-key encounter order preserved
out = solution.groups(["zebra", "Yak", "ZEBRA", "yak", "QUAIL"])
assert out == [["zebra", "ZEBRA"], ["Yak", "yak"], ["QUAIL"]], out

# 4. Original word order within groups + duplicates retained
assert solution.groups(["b", "a", "B", "b", "a"]) == [["b", "B", "b"], ["a", "a"]]

# 5. Unicode casefold semantics (German sharp s, Turkish-style dotless i etc.)
assert solution.groups(["Straße", "STRASSE", "strasse"]) == [
    ["Straße", "STRASSE", "strasse"]
]
assert solution.groups(["İstanbul", "i\u0307stanbul"]) == [
    ["İstanbul", "i\u0307stanbul"]
]

# 6. Edge cases
assert solution.groups([]) == []
assert solution.groups(["solo"]) == [["solo"]]
assert solution.groups(["", "x", ""]) == [["", ""], ["x"]]

# 7. Input not mutated (shallow and deep check)
src = ["B", "a", "b", "A"]
snapshot = copy.deepcopy(src)
ret = solution.groups(src)
assert src == snapshot, "input mutated"
assert ret is not src

# 8. Returns list of lists (exact types)
assert type(ret) is list and all(type(g) is list for g in ret)

# 9. Accepts any iterable without mutating non-list input
assert solution.groups(iter(["A", "a"])) == [["A", "a"]]
gen = (w for w in ["X", "x"])
assert solution.groups(gen) == [["X", "x"]]

# 10. Stdlib-only imports
tree = ast.parse(open("solution.py").read())
mods = set()
for node in ast.walk(tree):
    if isinstance(node, ast.Import):
        mods.update(a.name.split(".")[0] for a in node.names)
    elif isinstance(node, ast.ImportFrom):
        mods.add((node.module or "").split(".")[0])
assert mods <= set(sys.stdlib_module_names), f"non-stdlib imports: {mods}"

print("ALL CHECKS PASSED")
