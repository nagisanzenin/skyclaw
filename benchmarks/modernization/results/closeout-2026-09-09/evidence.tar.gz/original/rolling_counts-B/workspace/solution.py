def counts(events, width):
    """For each event timestamp t, count events in the window (t - width, t].

    events: nondecreasing list of integer timestamps.
    width: positive number (window half-open on the left).

    Raises:
        ValueError: if width is not positive, or if events is decreasing.
    """
    if width <= 0:
        raise ValueError("width must be positive")

    result = []
    left = 0
    prev = None
    for i, t in enumerate(events):
        if prev is not None and t < prev:
            raise ValueError("events must be nondecreasing")
        prev = t
        while events[left] <= t - width:
            left += 1
        result.append(i - left + 1)
    return result
