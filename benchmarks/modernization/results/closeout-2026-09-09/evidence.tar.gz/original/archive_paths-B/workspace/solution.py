"""Safe archive member path validation.

Pure string logic; performs no filesystem access. Standard library only.
"""


def safe_member(name):
    """Return True if *name* is a safe relative archive member path.

    Rejected:
      - non-strings and empty strings
      - any NUL character
      - any backslash
      - absolute paths (leading "/")
      - a first component ending in a colon (e.g. Windows drive forms "C:", "C:file")
      - any component exactly ".."

    Allowed: "." components, empty components from repeated forward slashes.
    """
    if not isinstance(name, str):
        return False
    if name == "":
        return False
    if "\x00" in name:
        return False
    if "\\" in name:
        return False
    if name.startswith("/"):
        return False

    components = name.split("/")

    # First component must not end with a colon (Windows drive-ish paths).
    if components[0].endswith(":"):
        return False

    for component in components:
        if component == "..":
            return False

    return True
