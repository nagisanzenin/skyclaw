def counts(events, width):
    """For each event timestamp t in `events`, count how many events seen so
    far fall in the window (t - width, t], including t itself and any
    earlier duplicates.

    `events` must be a nondecreasing list of integer timestamps;
    `width` must be positive. Violations raise ValueError.
    """
    if width <= 0:
        raise ValueError("width must be positive")

    result = []
    start = 0  # left edge of the sliding window (first index with events[start] > t - width)
    for i, t in enumerate(events):
        if i > 0 and t < events[i - 1]:
            raise ValueError("events must be nondecreasing")
        # Drop events that are <= t - width (outside the open lower bound).
        while events[start] <= t - width:
            start += 1
        # Events at indices start..i are all in (t - width, t].
        result.append(i - start + 1)
    return result
