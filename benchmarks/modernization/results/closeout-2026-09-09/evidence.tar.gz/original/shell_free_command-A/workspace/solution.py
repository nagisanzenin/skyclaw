"""run(args, cwd): execute a program directly (no shell) and capture output.

Standard library only. Returns a dict with keys:
  code   - int exit status (nonzero codes are returned, not raised)
  stdout - decoded UTF-8 text (invalid bytes replaced with U+FFFD)
  stderr - decoded UTF-8 text (invalid bytes replaced with U+FFFD)

Raises ValueError if args is empty or not a nonempty list of strings.
"""

from __future__ import annotations

import subprocess
from typing import Any, Dict, List


def run(args: List[str], cwd: Any) -> Dict[str, str | int]:
    if not isinstance(args, (list, tuple)):
        raise ValueError("args must be a nonempty list of strings")
    if len(args) == 0:
        raise ValueError("args must be a nonempty list of strings")
    if not all(isinstance(a, str) for a in args):
        raise ValueError("args must be a nonempty list of strings")

    completed = subprocess.run(
        list(args),
        shell=False,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    return {
        "code": completed.returncode,
        "stdout": completed.stdout.decode("utf-8", errors="replace"),
        "stderr": completed.stderr.decode("utf-8", errors="replace"),
    }
