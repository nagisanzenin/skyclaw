"""Self-checks for solution.run — standard library only."""
import os
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from solution import run

failures = []


def check(name, cond, detail=""):
    print(f"{'PASS' if cond else 'FAIL'}: {name}" + (f" | {detail}" if detail else ""))
    if not cond:
        failures.append(name)


# 1. Basic success: code 0, captured stdout/stderr
r = run([sys.executable, "-c", "print('hello')"], cwd=os.getcwd())
check("code 0 on success", r["code"] == 0, repr(r["code"]))
check("stdout captured", r["stdout"] == "hello\n", repr(r["stdout"]))
check("stderr empty", r["stderr"] == "", repr(r["stderr"]))

# 2. Nonzero exit returned, not raised
r = run([sys.executable, "-c", "import sys; print('out'); print('err', file=sys.stderr); sys.exit(3)"], cwd=os.getcwd())
check("nonzero code returned", r["code"] == 3, repr(r["code"]))
check("no exception for nonzero", isinstance(r, dict), type(r).__name__)
check("stdout on failure", r["stdout"] == "out\n", repr(r["stdout"]))
check("stderr on failure", r["stderr"] == "err\n", repr(r["stderr"]))

# 3. cwd is supplied and used
with tempfile.TemporaryDirectory() as td:
    marker = os.path.join(td, "marker.txt")
    with open(marker, "w") as f:
        f.write("ok")
    r = run([sys.executable, "-c", "import os; print(open('marker.txt').read())"], cwd=td)
    check("cwd used", r["code"] == 0 and r["stdout"] == "ok\n", repr(r))

# 4. Invalid UTF-8 bytes replaced, not crashed
with tempfile.TemporaryDirectory() as td:
    script = os.path.join(td, "bad.py")
    with open(script, "wb") as f:
        f.write(b"import sys\nsys.stdout.buffer.write(b'a\\xff\\xfeb\\x80c\\n')\nsys.stderr.buffer.write(b'E\\xff!\\n')\n")
    r = run([sys.executable, script], cwd=td)
    check("stdout replaced", r["stdout"] == "a\uFFFD\uFFFDb\uFFFDc\n", repr(r["stdout"]))
    check("stderr replaced", r["stderr"] == "E\uFFFD!\n", repr(r["stderr"]))

# 5. Empty args -> ValueError
for bad in ([], (), ""):
    try:
        run(bad, os.getcwd())
        check(f"ValueError for {bad!r}", False, "no exception")
    except ValueError:
        check(f"ValueError for {bad!r}", True)

# 6. Direct execution (no shell): a shell metacharacter is not interpreted
r = run([sys.executable, "-c", "print('$HOME')"], cwd=os.getcwd())
check("no shell expansion", r["stdout"].strip() == "$HOME", repr(r["stdout"]))

# 7. Missing binary: subprocess raises (documented behavior)
try:
    run(["definitely-not-a-real-binary-xyz"], cwd=os.getcwd())
    check("missing binary raises", False, "no exception")
except (FileNotFoundError, OSError):
    check("missing binary raises", True)

# 8. Standard library only
mods = {"os", "subprocess", "sys", "tempfile", "__future__", "typing"}
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "solution.py")) as f:
    src = f.read()
import ast
tree = ast.parse(src)
imports = set()
for node in ast.walk(tree):
    if isinstance(node, ast.Import):
        imports.update(a.name.split(".")[0] for a in node.names)
    elif isinstance(node, ast.ImportFrom):
        if node.module:
            imports.add(node.module.split(".")[0])
check("stdlib-only imports", imports <= mods, f"imports={sorted(imports)}")

print()
if failures:
    print(f"RESULT: {len(failures)} failure(s): {failures}")
    sys.exit(1)
print("RESULT: all checks passed")
