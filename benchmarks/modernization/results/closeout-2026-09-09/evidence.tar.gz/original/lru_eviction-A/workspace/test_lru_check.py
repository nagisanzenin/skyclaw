import solution
from solution import LRU

# capacity validation
for bad in (-1, -5, 1.5, "2", None, True, False, 2.0):
    try:
        LRU(bad)
        raise AssertionError(f"expected ValueError for {bad!r}")
    except ValueError:
        pass

LRU(0); LRU(3)  # valid

# put/get basic + recency marking on hit
c = LRU(2)
c.put("a", 1); c.put("b", 2)
assert c.keys() == ["a", "b"]
assert c.get("a") == 1                 # hit -> a becomes newest
assert c.keys() == ["b", "a"]
c.put("c", 3)                          # evicts b (oldest)
assert c.keys() == ["a", "c"]

# get miss returns default, no insertion
assert c.get("zzz") is None
assert c.get("zzz", "dflt") == "dflt"
assert c.keys() == ["a", "c"]

# put replace marks most recently used
c = LRU(2)
c.put("x", 1); c.put("y", 2); c.put("x", 10)  # x touched -> newest
assert c.keys() == ["y", "x"]
c.put("z", 3)                                  # evicts y
assert c.keys() == ["x", "z"]
assert c.get("x") == 10

# capacity zero retains nothing
z = LRU(0)
z.put("k", "v")
assert z.keys() == []
assert z.get("k", "miss") == "miss"

# eviction order across many inserts
c = LRU(3)
for i in range(5):
    c.put(i, i * i)
assert c.keys() == [2, 3, 4]
assert c.get(2) == 4 and c.keys() == [3, 4, 2]
c.put(5, 25)                                   # evicts 3
assert c.keys() == [4, 2, 5]

print("All checks passed.")
