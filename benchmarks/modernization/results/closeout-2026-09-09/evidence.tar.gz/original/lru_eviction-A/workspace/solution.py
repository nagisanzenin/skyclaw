"""LRU cache with a nonnegative integer capacity.

Uses collections.OrderedDict from the Python standard library to maintain
recency order: oldest entries first, newest entries last.
"""

from collections import OrderedDict


class LRU:
    """A fixed-capacity least-recently-used cache."""

    def __init__(self, capacity):
        if isinstance(capacity, bool) or not isinstance(capacity, int):
            raise ValueError("capacity must be a nonnegative integer")
        if capacity < 0:
            raise ValueError("capacity must be a nonnegative integer")
        self._capacity = capacity
        self._data = OrderedDict()  # oldest -> newest

    @property
    def capacity(self):
        return self._capacity

    def __len__(self):
        return len(self._data)

    def __contains__(self, key):
        return key in self._data

    def put(self, key, value):
        """Insert or replace key's value and mark it most recently used.

        Evicts the least recently used entry when capacity is exceeded.
        Capacity zero retains nothing.
        """
        if self._capacity <= 0:
            return
        if key in self._data:
            self._data.move_to_end(key, last=True)
        self._data[key] = value
        while len(self._data) > self._capacity:
            self._data.popitem(last=False)

    def get(self, key, default=None):
        """Return value for key and mark it most recently used on a hit.

        On a miss, return `default` without inserting anything.
        """
        if key not in self._data:
            return default
        self._data.move_to_end(key, last=True)
        return self._data[key]

    def keys(self):
        """Return a list of keys ordered oldest to newest."""
        return list(self._data.keys())
