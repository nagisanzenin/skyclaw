"""Group strings by their Unicode casefold key.

groups(words) returns a list of lists where each inner list contains the
original words sharing one casefold key. Groups appear in the order their
key is first encountered; words within a group keep their original order
and duplicates are retained. The input is not mutated.
"""

from collections import OrderedDict
from typing import Iterable, List


def groups(words: Iterable[str]) -> List[List[str]]:
    """Group strings by Unicode casefold key, preserving encounter order.

    Args:
        words: An iterable of strings to group.

    Returns:
        A list of lists; each inner list holds all original words (in
        order, duplicates included) whose ``str.casefold()`` keys match.
    """
    buckets: "OrderedDict[str, List[str]]" = OrderedDict()
    for word in words:
        key = word.casefold()
        bucket = buckets.get(key)
        if bucket is None:
            bucket = []
            buckets[key] = bucket
        bucket.append(word)
    return list(buckets.values())
