"""Load INI files into a merged dictionary using only the standard library."""

import configparser
import os


def load(paths):
    """Read INI files in order and return {section: {key: value}}.

    - Uses ConfigParser with interpolation disabled so percent signs
      remain literal.
    - Only explicit (non-DEFAULT) sections are keys of the result;
      inherited DEFAULT values are merged into each section's dict.
    - Keys are lowercased (configparser's default optionxform).
    - Files are read in order; later values override earlier ones,
      including DEFAULT-section values.
    - Raises FileNotFoundError if a path does not exist.
    """
    parser = configparser.ConfigParser(interpolation=None)

    for path in paths:
        if not os.path.isfile(path):
            raise FileNotFoundError(path)
        with open(path, "r", encoding="utf-8") as handle:
            parser.read_file(handle)

    # parser.sections() yields only explicitly declared sections
    # (the DEFAULT section is excluded). parser.items(section) returns
    # the section's options plus any inherited DEFAULT options, with
    # option keys already lowercased.
    return {section: dict(parser.items(section)) for section in parser.sections()}
