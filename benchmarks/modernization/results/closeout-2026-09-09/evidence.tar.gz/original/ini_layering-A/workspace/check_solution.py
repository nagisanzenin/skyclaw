"""Verification checks for solution.load — run and then delete."""
import os
import solution

results = []

# 1. Single file: DEFAULT inherited, keys lowercase, percent literal
r1 = solution.load(["base.ini"])
results.append(("single file result", r1))
assert r1 == {"server": {"port": "80", "literal": "50%", "host": "localhost"}}, r1

# 2. Multi-file: later overrides earlier
r2 = solution.load(["base.ini", "override.ini"])
results.append(("multi file result", r2))
assert r2 == {"server": {"port": "81", "literal": "50%",
                         "host": "localhost", "debug": "yes"}}, r2

# 3. Types: plain dict of dicts, string keys/values
assert type(r2) is dict and all(type(v) is dict for v in r2.values())
assert all(isinstance(k, str) for k in r2) and all(
    isinstance(k, str) for v in r2.values() for k in v)

# 4. Percent sign literal
assert r2["server"]["literal"] == "50%", r2["server"]["literal"]

# 5. Missing file raises FileNotFoundError
try:
    solution.load(["no_such_file.ini"])
except FileNotFoundError as e:
    results.append(("missing file raised FileNotFoundError", repr(e)))
else:
    raise AssertionError("FileNotFoundError not raised")

# 6. Later DEFAULT-section value overrides earlier DEFAULT value;
#    an explicit section option still beats DEFAULT (ConfigParser rule).
with open("_tmp_default_override.ini", "w", encoding="utf-8") as fh:
    fh.write("[DEFAULT]\nhost=otherhost\nport=999\n[extra]\nmode=fast\n")
r3 = solution.load(["base.ini", "override.ini", "_tmp_default_override.ini"])
results.append(("default override result", r3))
assert r3["server"]["host"] == "otherhost", r3          # later DEFAULT wins
assert r3["server"]["port"] == "81", r3                 # explicit option beats DEFAULT
assert r3["extra"] == {"host": "otherhost", "port": "999", "mode": "fast"}, r3
assert "DEFAULT" not in r3, r3                          # only explicit sections
os.remove("_tmp_default_override.ini")

# 7. Only standard library imports
import ast
tree = ast.parse(open("solution.py").read())
mods = set()
for node in ast.walk(tree):
    if isinstance(node, ast.Import):
        mods.update(a.name.split(".")[0] for a in node.names)
    elif isinstance(node, ast.ImportFrom):
        mods.add((node.module or "").split(".")[0])
results.append(("modules imported", sorted(mods)))
assert mods <= set(__import__("sys").stdlib_module_names), mods

print("ALL CHECKS PASSED")
for label, value in results:
    print(f"{label}: {value!r}")
