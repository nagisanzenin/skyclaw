"""Pure state-machine transition function (standard library only)."""

_TRANSITIONS = {
    ("pending", "start"): "running",
    ("running", "succeed"): "done",
    ("running", "fail"): "failed",
    ("pending", "cancel"): "cancelled",
    ("running", "cancel"): "cancelled",
}


def transition(state, event):
    """Return the next state for (state, event), or raise ValueError."""
    next_state = _TRANSITIONS.get((state, event))
    if next_state is None:
        raise ValueError(f"invalid transition: state={state!r}, event={event!r}")
    return next_state
