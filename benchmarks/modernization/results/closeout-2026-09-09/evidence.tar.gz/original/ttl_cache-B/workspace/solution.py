"""TTL cache with injectable clock (stdlib only)."""


class Cache:
    """A TTL cache whose expiry is driven by an injected clock callable.

    Entries are visible via get() only while clock() < expiry, where
    expiry = clock() + ttl at the time of the most recent put().
    """

    def __init__(self, ttl, clock):
        if not callable(clock):
            raise TypeError("clock must be callable")
        if ttl < 0:
            raise ValueError("ttl must be >= 0")
        self._ttl = ttl
        self._clock = clock
        self._store = {}  # key -> expiry

    @property
    def ttl(self):
        return self._ttl

    def put(self, key, value):
        """Store value under key; expiry is reset to clock() + ttl."""
        self._purge()
        self._store[key] = (self._clock() + self._ttl, value)

    def get(self, key, default=None):
        """Return the value for key while clock() < expiry, else default.

        Expired entries are removed when encountered.
        """
        entry = self._store.get(key)
        if entry is None:
            return default
        expiry, value = entry
        if self._clock() < expiry:
            return value
        del self._store[key]
        return default

    def __contains__(self, key):
        return self.get(key, _MISSING) is not _MISSING

    def __len__(self):
        self._purge()
        return len(self._store)

    def keys(self):
        """Return keys of live (non-expired) entries."""
        self._purge()
        return list(self._store.keys())

    def _purge(self):
        now = self._clock()
        expired = [k for k, (expiry, _) in self._store.items() if not (now < expiry)]
        for k in expired:
            del self._store[k]


_MISSING = object()
