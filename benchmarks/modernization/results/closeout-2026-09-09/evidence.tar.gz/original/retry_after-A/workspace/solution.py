"""Retry-After header parsing (standard library only)."""

import re
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

_INT_RE = re.compile(r"\A[0-9]+\Z")


def retry_after(value, now):
    """Return nonnegative float seconds indicated by a Retry-After value.

    ``value`` may be a nonnegative decimal integer string (seconds) or an
    RFC HTTP date. ``now`` is a timezone-aware datetime. Returns 0.0 for
    dates in the past and None for invalid input.
    """
    if not isinstance(value, str):
        return None
    if not isinstance(now, datetime) or now.tzinfo is None:
        return None

    text = value.strip()
    if not text:
        return None

    # Numeric seconds: digits only (no sign, no fraction).
    if _INT_RE.match(text):
        return float(int(text))

    # HTTP-date (IMF-fixdate, RFC 850, or asctime).
    try:
        target = parsedate_to_datetime(text)
    except (TypeError, ValueError):
        return None
    if not isinstance(target, datetime):
        return None
    if target.tzinfo is None:
        # RFC 850 / asctime forms carry no zone; HTTP dates are GMT.
        target = target.replace(tzinfo=timezone.utc)

    try:
        delta = (target - now).total_seconds()
    except (OverflowError, OSError, ValueError):
        return None
    if delta <= 0:
        return 0.0
    return delta
