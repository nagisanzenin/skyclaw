"""topk: return the k highest-scoring items, preserving original objects.

Items are dicts containing a "score" key. Results are sorted by score in
descending order; ties keep their original input order (stable sort).
The input sequence is never mutated.
"""

import heapq


def topk(items, k):
    """Return up to k items with the highest scores, sorted descending.

    Args:
        items: iterable of dict objects, each containing a "score" key.
        k: maximum number of items to return.

    Returns:
        A list of up to k of the *original* item objects, ordered by score
        descending, with ties resolved by original input order.

    Raises:
        ValueError: if k is negative.
    """
    if k < 0:
        raise ValueError("k must be non-negative, got %r" % (k,))
    if k == 0:
        return []

    # Snapshot the iterable so later mutation outside our control cannot
    # affect the ordering keys, and attach each item's input position so
    # ties are broken by original order even if scores are equal or
    # non-comparable objects are mixed.
    indexed = list(enumerate(items))
    if len(indexed) <= k:
        indexed.sort(key=lambda pair: (-pair[1]["score"], pair[0]))
        return [item for _, item in indexed]

    # heapq.nsmallest is O(n log k) and stable with respect to the key,
    # which includes the input index, so ordering matches the full sort.
    best = heapq.nsmallest(k, indexed, key=lambda pair: (-pair[1]["score"], pair[0]))
    return [item for _, item in best]
