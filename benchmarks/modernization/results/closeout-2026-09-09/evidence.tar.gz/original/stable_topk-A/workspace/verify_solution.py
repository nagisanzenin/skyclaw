import copy
import importlib.util
import sys

spec = importlib.util.spec_from_file_location("solution", "solution.py")
solution = importlib.util.module_from_spec(spec)
spec.loader.exec_module(solution)
topk = solution.topk

failures = []


def check(name, cond):
    if cond:
        print("PASS:", name)
    else:
        print("FAIL:", name)
        failures.append(name)


# 1. Basic descending sort
a, b, c = {"id": 1, "score": 3}, {"id": 2, "score": 9}, {"id": 3, "score": 5}
res = topk([a, b, c], 2)
check("returns k items", len(res) == 2)
check("sorted desc", [r["score"] for r in res] == [9, 5])
check("original objects (identity)", res[0] is b and res[1] is c)

# 2. Ties keep original input order
t1 = {"score": 7, "tag": "first"}
t2 = {"score": 7, "tag": "second"}
t3 = {"score": 7, "tag": "third"}
res = topk([t1, t2, t3], 3)
check("ties original order", [r["tag"] for r in res] == ["first", "second", "third"])
check("tie identity", res[0] is t1 and res[1] is t2 and res[2] is t3)

# 3. k larger than items
check("k > len returns all", len(topk([a, b, c], 100)) == 3)

# 4. k == 0
check("k==0 -> []", topk([a, b, c], 0) == [])

# 5. k negative raises ValueError
try:
    topk([a, b, c], -1)
    check("negative k raises ValueError", False)
except ValueError:
    check("negative k raises ValueError", True)
except Exception as e:
    print("FAIL: raised", type(e).__name__, "instead of ValueError")
    failures.append("negative k raises ValueError")

# 6. No mutation of input
items = [{"score": 1}, {"score": 5}, {"score": 3}, {"score": 5}]
snapshot = copy.deepcopy(items)
before_ids = [id(x) for x in items]
out = topk(items, 4)
check("input list order unchanged", items == snapshot)
check("input dict objects identical", all(id(x) in before_ids for x in out))
check("input dict contents unchanged", items == snapshot)

# 7. Empty input
check("empty input", topk([], 3) == [])

# 8. Works when items passed as a generator (iterable, not list)
gen = (dict(s) for s in [{"score": 2}, {"score": 8}])
check("accepts generator", [r["score"] for r in topk(gen, 2)] == [8, 2])

# 9. Stdlib only
src = open("solution.py").read()
banned = ["numpy", "pandas", "scipy", "requests", "sklearn"]
check("no third-party imports", not any(m in src for m in banned))

print()
if failures:
    print("RESULT: FAILED (%d)" % len(failures))
    sys.exit(1)
print("RESULT: ALL CHECKS PASSED")
