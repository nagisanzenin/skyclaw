"""Finite state machine transition function (pure, stdlib only)."""

_ALLOWED_EVENTS = frozenset({"start", "succeed", "fail", "cancel"})
_STATES = frozenset({"pending", "running", "done", "failed", "cancelled"})

# (state, event) -> next state
_TRANSITIONS = {
    ("pending", "start"): "running",
    ("running", "succeed"): "done",
    ("running", "fail"): "failed",
    ("pending", "cancel"): "cancelled",
    ("running", "cancel"): "cancelled",
}


def transition(state, event):
    """Return the next state for the given (state, event) pair.

    Valid transitions:
        start:   pending -> running
        succeed: running -> done
        fail:    running -> failed
        cancel:  pending | running -> cancelled

    Raises:
        ValueError: for any pair without a defined transition, including
            events on terminal states (done, failed, cancelled) and any
            unknown state or event name.
    """
    if state not in _STATES or event not in _ALLOWED_EVENTS:
        raise ValueError("invalid transition: state=%r, event=%r" % (state, event))
    try:
        return _TRANSITIONS[(state, event)]
    except KeyError:
        raise ValueError("invalid transition: state=%r, event=%r" % (state, event))
