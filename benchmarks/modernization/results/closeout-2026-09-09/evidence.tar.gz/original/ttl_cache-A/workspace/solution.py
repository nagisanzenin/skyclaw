"""TTL cache driven by an injected, caller-supplied clock (stdlib only)."""


class Cache:
    def __init__(self, ttl, clock):
        if ttl < 0:
            raise ValueError("ttl must be >= 0, got %r" % (ttl,))
        self._ttl = ttl
        self._clock = clock
        self._store = {}  # key -> (value, expiry)

    def put(self, key, value):
        """Store value under key; expiry is clock() + ttl (resets on fresh put)."""
        self._store[key] = (value, self._clock() + self._ttl)

    def get(self, key, default=None):
        """Return value only while clock() < expiry; purge expired entries."""
        entry = self._store.get(key)
        if entry is None:
            return default
        value, expiry = entry
        if self._clock() < expiry:
            return value
        del self._store[key]  # expired entries are removed
        return default

    def delete(self, key):
        """Explicitly remove a key (part of a minimal cache API)."""
        self._store.pop(key, None)

    def __contains__(self, key):
        """True iff key holds a live (unexpired) entry."""
        return self._store.get(key) is not None and self._clock() < self._store[key][1]

    def __len__(self):
        """Number of stored entries (including any not yet observed as expired)."""
        return len(self._store)
