import ast
import sys

import solution


def run():
    checks = []
    def ok(name, cond):
        checks.append((name, bool(cond)))

    # Fake controllable clock
    now = [100]
    clock = lambda: now[0]
    c = solution.Cache(ttl=10, clock=clock)

    # ttl validation
    try:
        solution.Cache(ttl=-1, clock=clock)
        ok("negative ttl raises", False)
    except ValueError:
        ok("negative ttl raises", True)
    ok("ttl=0 accepted", solution.Cache(ttl=0, clock=clock) is not None)

    # put sets expiry = clock() + ttl
    c.put("a", 1)
    ok("live get returns value", c.get("a") == 1)
    ok("default unused while live", c.get("a", "D") == 1)
    now[0] = 109
    ok("still live at clock()<expiry (109<110)", c.get("a") == 1)
    now[0] = 110
    ok("expired at clock()>=expiry returns default", c.get("a") is None)
    ok("expired returns custom default", c.get("a", "D") == "D")

    # expired entries removed from storage
    c.put("b", 2)
    now[0] = 200
    c.get("b")
    ok("expired entry removed internally", len(c._store) == 0)
    ok("missing key -> default", c.get("nope", "X") == "X" and c.get("nope") is None)

    # fresh put resets expiry from current clock
    now[0] = 300
    c.put("c", 3)          # expiry 310
    now[0] = 309
    ok("live before old expiry", c.get("c") == 3)
    now[0] = 315
    ok("expired after ttl from put time", c.get("c") is None)
    now[0] = 1000
    c.put("c", 3)          # expiry 1010
    now[0] = 1009
    ok("live again after fresh put", c.get("c") == 3)
    now[0] = 1005
    c.put("c", 9)          # reset: expiry 1015
    now[0] = 1012
    ok("fresh put reset expiry (live at 1012)", c.get("c") == 9)
    now[0] = 1015
    ok("reset expiry honoured (dead at 1015)", c.get("c") is None)

    # stdlib only, no real-clock / sleep dependency (AST-based)
    src = open("solution.py").read()
    tree = ast.parse(src)
    mods = {a.name.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names}
    mods |= {n.module.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.module}
    ok("imports within stdlib", mods <= set(sys.stdlib_module_names))
    # real-clock detection: any attribute access rooted at the `time` module
    time_attr = any(
        isinstance(n, ast.Attribute)
        and isinstance(n.value, ast.Name)
        and n.value.id == "time"
        for n in ast.walk(tree)
    )
    time_imported = "time" in mods
    ok("no time-module import or time.* usage", not time_imported and not time_attr)
    ok("no sleep call", "sleep(" not in src)

    for name, passed in checks:
        print(("PASS" if passed else "FAIL"), "-", name)
    failed = [n for n, p in checks if not p]
    print("\n%d/%d passed" % (len(checks) - len(failed), len(checks)))
    return 0 if not failed else 1


sys.exit(run())
