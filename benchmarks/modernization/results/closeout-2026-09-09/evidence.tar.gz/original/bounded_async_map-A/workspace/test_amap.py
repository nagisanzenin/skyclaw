import asyncio
import sys

from solution import amap


def run(coro):
    return asyncio.run(coro)


# 1. Order preservation despite varying completion times
async def t_order():
    async def fn(x):
        await asyncio.sleep(0.05 * (10 - x))  # later items finish first
        return x * 2

    res = await amap(fn, list(range(10)), 3)
    assert res == [x * 2 for x in range(10)], res
    # generator input
    res2 = await amap(fn, (i for i in range(5)), 2)
    assert res2 == [0, 2, 4, 6, 8], res2


# 2. Concurrency cap respected
async def t_limit():
    active = 0
    peak = 0
    log = []

    async def fn(x):
        nonlocal active, peak
        active += 1
        peak = max(peak, active)
        log.append(("start", x))
        await asyncio.sleep(0.01)
        active -= 1
        return x

    await amap(fn, list(range(20)), 4)
    assert peak == 4, f"peak={peak}"
    # at most 4 started before any finish
    assert sum(1 for e in log[:4] if e[0] == "start") == 4


# 3. limit <= 0 raises ValueError
async def t_valueerror():
    async def fn(x):
        return x

    for bad in (0, -1, -100):
        try:
            await amap(fn, [1, 2, 3], bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"limit={bad} did not raise ValueError")
    # empty items with bad limit still raises
    try:
        await amap(fn, [], 0)
    except ValueError:
        pass
    else:
        raise AssertionError("empty items + limit=0 did not raise")


# 4. Failure: original exception re-raised; outstanding tasks cancelled & awaited
async def t_failure():
    events = []

    async def slow(tag, delay):
        try:
            await asyncio.sleep(delay)
            events.append(("done", tag))
            return tag
        except asyncio.CancelledError:
            events.append(("cancelled", tag))
            await asyncio.sleep(0.01)  # cleanup work after cancellation
            events.append(("cleanup", tag))
            raise

    async def boom():
        await asyncio.sleep(0.02)
        raise RuntimeError("original-boom")

    async def fn(x):
        if x == 0:
            return await boom()
        return await slow(x, 5.0)

    try:
        await amap(fn, list(range(6)), 3)
    except RuntimeError as e:
        assert str(e) == "original-boom", str(e)
    else:
        raise AssertionError("exception not re-raised")

    # every task that was started (limit=3) got cancelled and fully cleaned up
    started = sorted(t[1] for t in events if t[0] == "cancelled")
    cleaned = sorted(t[1] for t in events if t[0] == "cleanup")
    assert started == [1, 2, 3], started
    assert cleaned == [1, 2, 3], cleaned
    assert ("done", 1) not in events, events


# 5. Edge cases: empty items, limit=1, limit larger than item count


async def t_edges():
    async def fn(x):
        await asyncio.sleep(0.001)
        return x + 1

    assert await amap(fn, [], 5) == []
    assert await amap(fn, [1, 2, 3], 1) == [2, 3, 4]
    assert await amap(fn, [1, 2], 100) == [2, 3]


async def main():
    await t_order()
    await t_limit()
    await t_valueerror()
    await t_failure()
    await t_edges()
    print("ALL TESTS PASSED")


if __name__ == "__main__":
    sys.exit(run(main()) or 0)
