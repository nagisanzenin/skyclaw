"""Async bounded-concurrency mapper using only the Python standard library."""

import asyncio
from typing import Any, Awaitable, Callable, Iterable, List


async def amap(
    fn: Callable[[Any], Awaitable[Any]],
    items: Iterable[Any],
    limit: int,
) -> List[Any]:
    """Apply async *fn* to every item in *items* with bounded concurrency.

    At most *limit* calls to *fn* are active at any moment. Results are
    returned in input order regardless of completion order.

    Raises:
        ValueError: if *limit* is <= 0.
        BaseException: the original exception raised by *fn*; all outstanding
            tasks are cancelled and awaited before it propagates.
    """
    if limit <= 0:
        raise ValueError("limit must be a positive integer")

    semaphore = asyncio.Semaphore(limit)

    async def _run(item: Any) -> Any:
        async with semaphore:
            return await fn(item)

    tasks = [asyncio.ensure_future(_run(item)) for item in items]
    try:
        # gather preserves input order in its result list.
        return await asyncio.gather(*tasks)
    except BaseException:
        # On failure: cancel every outstanding task and wait for all of them
        # to actually finish before re-raising the original exception.
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        raise
