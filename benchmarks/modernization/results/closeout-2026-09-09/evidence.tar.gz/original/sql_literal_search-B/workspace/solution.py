"""Search documents by a literal title fragment.

The ``documents`` table is expected to exist in the given connection with the
schema::

    documents(id INTEGER, title TEXT)

``search`` returns every row whose *title* contains ``fragment`` as a literal
substring, using SQLite's case-insensitive LIKE semantics for ASCII letters.
``%`` and ``_`` inside ``fragment`` are treated as ordinary characters, not
wildcards, so they are escaped in the pattern and the escape is declared with
an ``ESCAPE`` clause. The fragment itself is bound as an SQL parameter.
"""

import sqlite3


def search(conn, fragment):
    """Return ``(id, title)`` tuples whose title contains ``fragment``.

    Matching follows SQLite ``LIKE`` semantics (case-insensitive for ASCII),
    with ``%`` and ``_`` in ``fragment`` treated as literal characters.
    Results are ordered by ``id``.
    """
    # Escape LIKE wildcards so they match themselves literally.
    escaped = fragment.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    pattern = "%" + escaped + "%"

    cur = conn.execute(
        "SELECT id, title FROM documents "
        "WHERE title LIKE ? ESCAPE '\\' "
        "ORDER BY id",
        (pattern,),
    )
    return cur.fetchall()


if __name__ == "__main__":
    conn = sqlite3.connect(":memory:")
    conn.execute("CREATE TABLE documents (id INTEGER, title TEXT)")
    conn.executemany(
        "INSERT INTO documents VALUES (?, ?)",
        [
            (3, "Path_To_File"),
            (1, "Sales Report 2024"),
            (2, "path_to_file"),
            (4, "100% Done"),
            (5, "Percent only"),
            (6, None),
        ],
    )

    print("literal 'p':", search(conn, "p"))          # ids 2, 3
    print("underscore :", search(conn, "Path_To"))    # id 3 only (underscore literal)
    print("percent    :", search(conn, "100% D"))     # id 4 only (percent literal)
    print("no match   :", search(conn, "zzz"))        # []
