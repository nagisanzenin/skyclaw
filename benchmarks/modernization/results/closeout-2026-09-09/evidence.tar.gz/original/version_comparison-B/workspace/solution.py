"""compare(a, b): compare dot-separated nonnegative integer version strings.

Rules:
- Inputs are strings of one or more dot-separated nonnegative ASCII integer
  components. Leading zeros are allowed (e.g. "007").
- Trailing zero components are ignored for comparison purposes
  (e.g. "1.0.0" == "1").
- Comparison is numeric lexicographic; missing components count as zero
  (e.g. "1.2" < "1.2.1", "1.10" > "1.9").
- Invalid input raises ValueError.
- Uses only the Python standard library.
"""

import re

_COMPONENT_RE = re.compile(r"[0-9]+", re.ASCII)


def _parse(value):
    """Parse a version string into a tuple of ints with trailing zeros stripped.

    Raises ValueError for anything that is not a valid version string.
    """
    if not isinstance(value, str):
        raise ValueError(
            "expected a string, got %s" % type(value).__name__
        )
    components = value.split(".")
    parsed = []
    for component in components:
        if not _COMPONENT_RE.fullmatch(component):
            raise ValueError(
                "invalid version string: %r" % (value,)
            )
        parsed.append(int(component))
    # Strip trailing zero components ("1.0.0" == "1", "0.0" == "0").
    while parsed and parsed[-1] == 0:
        parsed.pop()
    return tuple(parsed)


def compare(a, b):
    """Return -1, 0 or 1 comparing version strings a and b."""
    ta, tb = _parse(a), _parse(b)
    length = max(len(ta), len(tb))
    for i in range(length):
        ca = ta[i] if i < len(ta) else 0
        cb = tb[i] if i < len(tb) else 0
        if ca < cb:
            return -1
        if ca > cb:
            return 1
    return 0
