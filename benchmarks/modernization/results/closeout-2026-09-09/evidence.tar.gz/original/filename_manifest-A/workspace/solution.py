"""manifest(root): sorted relative POSIX paths of regular files under root.

Symlinks (files or directories) are never followed. Hidden files are
included. Directory entries themselves are omitted. Standard library only.
"""

import os
import stat


def _is_regular_file(entry):
    """True if entry is a regular file, without following symlinks."""
    try:
        st = entry.stat(follow_symlinks=False)
    except OSError:
        return False
    return stat.S_ISREG(st.st_mode)


def manifest(root):
    """Recursively return sorted relative POSIX paths of regular files under root.

    - Symlink files and symlink directories are not followed / not included.
    - Hidden files are included.
    - Directory entries themselves are omitted from the result.
    - Paths are returned as POSIX-style relative strings ('/' separators),
      sorted lexicographically.
    """
    root = os.fspath(root)
    results = []

    def walk(dir_path, rel):
        try:
            entries = list(os.scandir(dir_path))
        except OSError:
            return
        for entry in entries:
            rel_child = name = entry.name
            if rel:
                rel_child = rel + "/" + name
            try:
                if entry.is_symlink():
                    # Never follow or include symlinks (files or dirs).
                    continue
                if entry.is_dir(follow_symlinks=False):
                    walk(entry.path, rel_child)
                elif _is_regular_file(entry):
                    results.append(rel_child)
            except OSError:
                continue

    walk(root, "")
    results.sort()
    return results
