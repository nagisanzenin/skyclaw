def parse(text):
    """Parse simple key=value lines.

    Rules:
    - One key=value pair per nonblank line; split on the first '=' only.
    - Keys and values are stripped of surrounding whitespace.
    - Lines whose stripped form starts with '#' are ignored (comments).
    - Blank (whitespace-only) lines are ignored.
    - Keys must be nonempty after stripping.
    - Duplicate keys raise ValueError.
    - Noncomment lines without '=' raise ValueError.
    """
    result = {}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue
        if '=' not in stripped:
            raise ValueError(
                "invalid line (no '='): %r" % line
            )
        key, _, value = stripped.partition('=')
        key = key.strip()
        if not key:
            raise ValueError(
                "empty key in line: %r" % line
            )
        if key in result:
            raise ValueError(
                "duplicate key: %r" % key
            )
        result[key] = value.strip()
    return result
