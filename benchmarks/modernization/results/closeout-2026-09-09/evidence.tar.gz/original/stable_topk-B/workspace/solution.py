"""topk: return the k highest-scoring items, preserving input order on ties."""


def topk(items, k):
    """Return up to k original objects from *items* sorted by score descending.

    Items are dicts containing a "score" key. Ties are broken by original
    input order (stable). The input list is not mutated; the returned list
    contains the original dict objects (not copies).

    Raises:
        ValueError: if k is negative.
    """
    if k < 0:
        raise ValueError("k must be non-negative")
    if k == 0 or not items:
        return []
    # sorted() is stable, so equal scores keep their original input order.
    # Using -score as the key (rather than reverse=True) keeps the largest
    # scores first while ties stay in input order.
    return sorted(items, key=lambda item: -item["score"])[:k]
