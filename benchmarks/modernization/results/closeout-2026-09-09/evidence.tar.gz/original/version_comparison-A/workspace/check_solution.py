import sys

from solution import compare

fails = []


def eq(a, b, expected):
    try:
        got = compare(a, b)
    except Exception as exc:  # noqa: BLE001
        fails.append(f"compare({a!r},{b!r}) raised {exc!r}, expected {expected}")
        return
    if got != expected or not isinstance(got, int):
        fails.append(f"compare({a!r},{b!r}) = {got!r}, expected {expected}")


def raises(a, b):
    try:
        compare(a, b)
    except ValueError:
        return
    except Exception as exc:  # noqa: BLE001
        fails.append(f"compare({a!r},{b!r}) raised {type(exc).__name__}, expected ValueError")
        return
    fails.append(f"compare({a!r},{b!r}) did not raise ValueError")


# Equality (order-insensitive, trailing zeros, leading zeros, big ints)
eq("1", "1", 0)
eq("1", "1.0", 0)
eq("1", "1.0.0.0", 0)
eq("1.0.1", "1.0.1.0", 0)
eq("01", "1", 0)
eq("1.02", "1.2", 0)
eq("0", "0.0", 0)
eq("0001.000", "1", 0)
eq("9999999999999999999999999999", "9999999999999999999999999999", 0)
eq("1.0.0.0.0.1", "1.0.0.0.0.1.0", 0)

# Less than
eq("1", "2", -1)
eq("1.2", "1.2.1", -1)
eq("1.2", "1.10", -1)
eq("2.0", "10.0", -1)
eq("0.1", "1", -1)
eq("1.2.3", "1.2.10", -1)
eq("9", "10", -1)

# Greater than
eq("2", "1", 1)
eq("1.2.1", "1.2", 1)
eq("1.10", "1.2", 1)
eq("10", "9", 1)
eq("1.2.10", "1.2.3", 1)
eq("1.0.1", "1", 1)

# Invalid inputs raise ValueError
raises("", "")
raises("", "1")
raises("1", "")
raises("1..2", "1")
raises(".1", "1")
raises("1.", "1")
raises("-1", "1")
raises("+1", "1")
raises(" 1", "1")
raises("1 ", "1")
raises("1a", "1")
raises("a.b", "1")
raises("١", "1")          # non-ASCII digit
raises("1．2", "1")       # non-ASCII dot
raises("1\n", "1")
raises("1.0x", "1")

# Non-string types
for bad in (1, 1.2, None, b"1.2", ["1"], ("1",), True):
    try:
        compare(bad, "1")
    except ValueError:
        pass
    else:
        fails.append(f"compare({bad!r}, '1') did not raise ValueError")

# Result type must be int in {-1, 0, 1}
for pair in (("1", "2"), ("1", "1"), ("2", "1")):
    r = compare(*pair)
    if r not in (-1, 0, 1) or type(r) is not int:
        fails.append(f"compare{pair} returned {r!r} of type {type(r).__name__}")

if fails:
    print("FAILURES:")
    for f in fails:
        print(" -", f)
    sys.exit(1)
print("ALL CHECKS PASSED")
