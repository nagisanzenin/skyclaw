"""Dot-separated numeric version comparison.

compare(a, b) compares strings of one or more dot-separated nonnegative
integer components, e.g. "1.2.3" vs "1.2.10".

Rules:
  * Components are nonnegative integers written in ASCII digits; leading
    zeros are allowed ("1.02" == "1.2").
  * Trailing zero components are ignored ("1.0.0" == "1").
  * Missing components compare as zero ("1.2" vs "1.2.0" -> 0;
    "1.2" vs "1.2.1" -> -1).
  * Result: -1 if a < b, 0 if equal, 1 if a > b.
  * Invalid input raises ValueError.

Only the Python standard library is used.
"""

import re

_COMPONENT = re.compile(r"\A[0-9]+\Z")
_ALLOWED = frozenset("0123456789.")


def compare(a, b):
    """Compare two dot-separated nonnegative-integer version strings.

    Returns -1, 0, or 1 (int). Raises ValueError on invalid input.
    """
    if not isinstance(a, str) or not isinstance(b, str):
        raise ValueError("compare() expects string arguments")
    xs = _components(a)
    ys = _components(b)
    # Pad the shorter list with zeros so missing components read as zero
    # and trailing zero components are ignored.
    n = max(len(xs), len(ys))
    xs += [0] * (n - len(xs))
    ys += [0] * (n - len(ys))
    if xs < ys:
        return -1
    if xs > ys:
        return 1
    return 0


def _components(s):
    """Validate a version string and return its integer components,
    most significant first."""
    if s == "":
        raise ValueError("empty string is not a valid version")
    # ASCII-only digits and dots: rejects letters, signs, whitespace,
    # and any non-ASCII characters.
    if not _ALLOWED.issuperset(s):
        raise ValueError(f"invalid characters in version: {s!r}")
    for part in s.split("."):
        if not _COMPONENT.match(part):
            raise ValueError(f"invalid component in version: {s!r}")
    # Python ints are arbitrary precision, so int() is safe for any length.
    return [int(part) for part in s.split(".")]
