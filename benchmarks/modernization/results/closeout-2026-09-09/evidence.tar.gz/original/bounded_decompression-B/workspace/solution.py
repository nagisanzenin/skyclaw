"""Bounded single-stream gzip decompression.

inflate(data, limit) decompresses a gzip byte stream but never produces more
than limit + 1 uncompressed bytes, so memory usage stays bounded even for
hostile (zip-bomb style) inputs.
"""

import gzip
import io


def inflate(data: bytes, limit: int) -> bytes:
    """Decompress a single gzip byte stream with a hard output bound.

    Args:
        data: A gzip-compressed byte stream (a single member).
        limit: Maximum allowed uncompressed length. Must be a non-negative
            integer.

    Returns:
        The decompressed bytes, but only if len(result) <= limit.

    Raises:
        ValueError: If limit is negative or not an integer, or if the
            uncompressed length exceeds limit.
        OSError / EOFError: Propagated from gzip for malformed input.
    """
    if not isinstance(limit, int) or isinstance(limit, bool):
        raise ValueError("limit must be a non-negative integer")
    if limit < 0:
        raise ValueError("limit must be non-negative")

    reader = io.BytesIO(data)
    chunks = []
    produced = 0

    # gzip.GzipFile.read(n) yields at most n bytes per call; by capping the
    # total at limit + 1 we stop decompressing as soon as the input is known
    # to exceed the limit, never inflating the whole payload.
    with gzip.GzipFile(fileobj=reader, mode="rb") as gz:
        while produced <= limit:
            chunk = gz.read(limit + 1 - produced)
            if not chunk:
                break
            chunks.append(chunk)
            produced += len(chunk)

    if produced > limit:
        raise ValueError(
            "uncompressed length %d exceeds limit %d" % (produced, limit)
        )

    return b"".join(chunks)
