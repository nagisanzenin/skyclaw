"""LRU cache implementation using only the Python standard library."""

from collections import OrderedDict


class LRU:
    """Least-Recently-Used cache with a fixed, nonnegative capacity.

    - put(key, value): inserts or replaces the value and marks the key as
      most recently used, evicting the least recently used entry if the
      capacity would be exceeded.
    - get(key, default=None): returns the value and marks the key as most
      recently used on a hit; on a miss returns ``default`` without any
      insertion.
    - keys(): returns keys ordered from least recently (oldest) to most
      recently (newest) used.

    A capacity of zero retains nothing.
    """

    def __init__(self, capacity):
        if not isinstance(capacity, int) or isinstance(capacity, bool):
            raise ValueError("capacity must be a nonnegative integer")
        if capacity < 0:
            raise ValueError("capacity must be a nonnegative integer")
        self._capacity = capacity
        self._data = OrderedDict()

    @property
    def capacity(self):
        return self._capacity

    def __len__(self):
        return len(self._data)

    def __contains__(self, key):
        return key in self._data

    def put(self, key, value):
        if key in self._data:
            self._data[key] = value
            self._data.move_to_end(key)
            return
        if self._capacity == 0:
            return
        if len(self._data) >= self._capacity:
            self._data.popitem(last=False)  # evict least recently used
        self._data[key] = value

    def get(self, key, default=None):
        if key not in self._data:
            return default
        self._data.move_to_end(key)
        return self._data[key]

    def keys(self):
        """Return a list of keys from oldest (LRU) to newest (MRU)."""
        return list(self._data.keys())
