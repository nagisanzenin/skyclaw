import sys

from solution import LRU

failures = []


def check(name, cond, detail=""):
    if cond:
        print(f"PASS: {name}")
    else:
        failures.append(name)
        print(f"FAIL: {name} {detail}")


# --- capacity validation ---
for bad in (-1, -5, 1.5, "2", None, True, False):
    try:
        LRU(bad)
        check(f"capacity={bad!r} raises ValueError", False, "(no exception)")
    except ValueError:
        check(f"capacity={bad!r} raises ValueError", True)
    except Exception as e:  # noqa: BLE001
        check(f"capacity={bad!r} raises ValueError", False, f"(got {type(e).__name__})")

for good in (0, 1, 2, 100, 10**6):
    try:
        c = LRU(good)
        check(f"capacity={good} accepted", True)
    except Exception as e:  # noqa: BLE001
        check(f"capacity={good} accepted", False, f"(got {type(e).__name__}: {e})")

# --- zero capacity retains nothing ---
c0 = LRU(0)
c0.put("a", 1)
c0.put("b", 2)
check("zero capacity stores nothing", len(c0) == 0 and c0.keys() == [])
check("zero capacity get miss", c0.get("a", "dflt") == "dflt" and c0.get("a") is None)

# --- basic put/get ---
c = LRU(3)
check("new cache empty", c.keys() == [])
c.put("a", 1)
c.put("b", 2)
c.put("c", 3)
check("insertion order keys", c.keys() == ["a", "b", "c"])
check("get hits", (c.get("a"), c.get("b"), c.get("c")) == (1, 2, 3))

# --- get marks used ---
c = LRU(3)
c.put("a", 1)
c.put("b", 2)
c.put("c", 3)
check("pre-access order", c.keys() == ["a", "b", "c"])
check("get a returns 1", c.get("a") == 1)
check("access bumps a to newest", c.keys() == ["b", "c", "a"])
c.put("d", 4)  # evicts b (oldest)
check("eviction after access order", c.keys() == ["c", "a", "d"])
check("evicted key misses with default", c.get("b", "gone") == "gone")

# --- put replaces and marks MRU ---
c = LRU(2)
c.put("a", 1)
c.put("b", 2)
c.put("a", 10)  # replace a, becomes MRU
check("put replaces value", c.get("a") == 10)
check("put marks MRU", c.keys() == ["b", "a"])
c.put("c", 3)  # evicts b, not a
check("put-based MRU affects eviction", c.keys() == ["a", "c"])

# --- miss does not insert; default configurable ---
c = LRU(2)
c.put("x", 1)
check("miss returns default None", c.get("nope") is None)
check("miss custom default", c.get("nope", 42) == 42)
check("miss did not insert", c.keys() == ["x"])

# --- eviction on overflow ---
c = LRU(2)
c.put(1, "one")
c.put(2, "two")
c.put(3, "three")
check("overflow evicts oldest", c.keys() == [2, 3])
check("evicted key gone", c.get(1) is None)

# --- capacity 1 ---
c = LRU(1)
c.put("a", 1)
c.put("b", 2)
check("capacity 1 keeps only last", c.keys() == ["b"] and c.get("a") is None)

# --- keys() returns a list (snapshot), order oldest->newest ---
c = LRU(3)
for i in range(3):
    c.put(i, i * 10)
ks = c.keys()
check("keys returns list", isinstance(ks, list))
check("keys independent snapshot", c.keys() == [0, 1, 2] and ks is not c.keys())

# --- re-inserting an evicted key works ---
c = LRU(2)
c.put("k", 1)
c.put("z", 2)  # k evicted
c.put("k", 99)
check("reinsert after eviction", c.keys() == ["z", "k"] and c.get("k") == 99)

# --- falsy values preserved ---
c = LRU(2)
c.put("z", 0)
c.put("e", "")
check("falsy value get", c.get("z") == 0 and c.get("e") == "")

# --- non-int keys and None values ---
c = LRU(2)
c.put(None, "n")
c.put((1, 2), "t")
check("None/tuple keys", c.get(None) == "n" and c.get((1, 2)) == "t")

# --- only stdlib used ---
import solution as mod
import types

allowed_stdlib = sys.stdlib_module_names
imports = []
for name, val in vars(mod).items():
    if isinstance(val, types.ModuleType) and getattr(val, "__name__", None):
        imports.append(val.__name__)
check("imports are stdlib only", all(i.split(".")[0] in allowed_stdlib for i in imports), f"imports={imports}")

print()
if failures:
    print(f"RESULT: {len(failures)} failure(s): {failures}")
    sys.exit(1)
print("RESULT: ALL CHECKS PASSED")
