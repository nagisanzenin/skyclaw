"""Apply a list of account events and return the resulting balances.

Rules:
- Each event is a dict with keys ``id``, ``account`` and ``delta`` (int).
- The first occurrence of each ``id`` applies its ``delta`` to its ``account``.
- A later event whose ``id`` repeats with the same ``account`` and ``delta``
  is an exact duplicate and is ignored.
- A later event whose ``id`` repeats with a different ``account`` or
  ``delta`` raises ``ValueError``.
- The input is not modified.
"""


def apply(events):
    """Return a dict mapping account -> balance after processing *events*."""
    seen = {}       # id -> (account, delta) of the first occurrence
    balances = {}   # account -> running balance

    for event in events:
        event_id = event["id"]
        account = event["account"]
        delta = event["delta"]
        record = (account, delta)

        if event_id in seen:
            if seen[event_id] != record:
                raise ValueError(
                    "conflicting event for id {!r}: first seen as {}, "
                    "got {}".format(event_id, seen[event_id], record)
                )
            continue  # exact duplicate: ignore

        seen[event_id] = record
        balances[account] = balances.get(account, 0) + delta

    return balances
