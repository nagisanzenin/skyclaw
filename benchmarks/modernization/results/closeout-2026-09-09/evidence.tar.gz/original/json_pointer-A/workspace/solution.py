"""JSON Pointer (RFC 6901) resolution, standard library only."""

import re

_INDEX_RE = re.compile(r"^(?:0|[1-9][0-9]*)$")


def _decode(token):
    """Decode a single reference token: ~1 -> '/', ~0 -> '~'.

    Any '~' not followed by '0' or '1' is invalid.
    """
    if "~" in token:
        out = []
        i = 0
        n = len(token)
        while i < n:
            ch = token[i]
            if ch == "~":
                if i + 1 >= n or token[i + 1] not in ("0", "1"):
                    raise ValueError(
                        "invalid JSON Pointer escape in token: %r" % token
                    )
                out.append("/" if token[i + 1] == "1" else "~")
                i += 2
            else:
                out.append(ch)
                i += 1
        return "".join(out)
    return token


def resolve(document, pointer):
    """Resolve a JSON Pointer against *document* and return the target value."""
    if not isinstance(pointer, str):
        raise ValueError("JSON Pointer must be a string")

    if pointer == "":
        return document

    if not pointer.startswith("/"):
        raise ValueError("JSON Pointer must be empty or start with '/'")

    current = document
    tokens = pointer.split("/")[1:]  # first element is '' from the leading '/'
    for raw in tokens:
        key = _decode(raw)

        if isinstance(current, dict):
            if key not in current:
                raise ValueError("missing key %r in object" % key)
            current = current[key]
        elif isinstance(current, list):
            if not _INDEX_RE.match(key):
                raise ValueError("invalid array index %r" % raw)
            index = int(key)
            if index >= len(current):
                raise ValueError("array index %d out of range" % index)
            current = current[index]
        else:
            raise ValueError(
                "cannot traverse scalar of type %s" % type(current).__name__
            )

    return current
