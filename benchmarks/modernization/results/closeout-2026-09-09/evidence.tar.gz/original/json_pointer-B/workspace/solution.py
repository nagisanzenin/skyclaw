"""JSON Pointer (RFC 6901 style) resolution with strict validation."""

import re


def _decode_component(raw):
    """Decode a single pointer component; ~1 -> '/', ~0 -> '~'.

    Any tilde escape other than ~0 or ~1 is invalid (including a
    trailing bare '~').
    """
    out = []
    i = 0
    n = len(raw)
    while i < n:
        ch = raw[i]
        if ch == '~':
            if i + 1 >= n:
                raise ValueError(
                    "invalid pointer component %r: dangling '~'" % raw)
            esc = raw[i + 1]
            if esc == '0':
                out.append('~')
            elif esc == '1':
                out.append('/')
            else:
                raise ValueError(
                    "invalid tilde escape '~%s' in pointer component %r"
                    % (esc, raw))
            i += 2
        else:
            out.append(ch)
            i += 1
    return ''.join(out)


# Canonical nonnegative list index: "0" or a digit 1-9 followed by digits.
_INDEX_RE = re.compile(r'^(?:0|[1-9][0-9]*)$')


def resolve(document, pointer):
    """Resolve *pointer* against *document* and return the referenced value.

    - The empty pointer resolves to the document itself.
    - Otherwise the pointer must start with '/'.
    - Components are unescaped ('~1' -> '/', '~0' -> '~'); any other tilde
      usage raises ValueError.
    - Dict components are treated as keys; list components must be canonical
      nonnegative decimal indices ("0", or nonzero leading digit).
    - Missing keys/indices, malformed indices, non-/ prefixes, and traversal
      into scalars all raise ValueError.
    """
    if not isinstance(pointer, str):
        raise ValueError("pointer must be a string, got %r" % type(pointer))

    if pointer == '':
        return document

    if not pointer.startswith('/'):
        raise ValueError(
            "non-empty pointer must start with '/': %r" % pointer)

    raw_components = pointer.split('/')[1:]
    current = document

    for raw in raw_components:
        token = _decode_component(raw)

        if isinstance(current, dict):
            if token not in current:
                raise ValueError("key not found: %r" % token)
            current = current[token]
        elif isinstance(current, list):
            if not _INDEX_RE.match(token):
                raise ValueError(
                    "invalid list index %r (must be canonical "
                    "nonnegative decimal)" % token)
            idx = int(token)
            if idx >= len(current):
                raise ValueError(
                    "list index out of range: %d (length %d)"
                    % (idx, len(current)))
            current = current[idx]
        else:
            raise ValueError(
                "cannot traverse scalar value %r with component %r"
                % (current, token))

    return current
