"""Weighted arithmetic mean.

Implements mean(pairs) where pairs is an iterable of (value, weight) tuples.
Only the Python standard library is used.
"""

import math

__all__ = ["mean"]


def _is_real_number(x):
    """True if x is a real int/float (bools excluded) and finite."""
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        return False
    return math.isfinite(x)


def mean(pairs):
    """Return the weighted arithmetic mean of (value, weight) pairs.

    Raises:
        ValueError: if pairs is empty, any value/weight is not a finite
            real number, any weight is negative, or the total weight is 0.
    """
    if pairs is None:
        raise ValueError("pairs must be an iterable of (value, weight) pairs")

    total_weight = 0.0
    weighted_sum = 0.0
    count = 0

    try:
        iterator = iter(pairs)
    except TypeError:
        raise ValueError("pairs must be an iterable of (value, weight) pairs")

    for pair in iterator:
        count += 1
        try:
            value, weight = pair
        except (TypeError, ValueError):
            raise ValueError(
                "each item must be a (value, weight) pair, got %r" % (pair,)
            )

        if not _is_real_number(value):
            raise ValueError("value must be a finite number, got %r" % (value,))
        if not _is_real_number(weight):
            raise ValueError("weight must be a finite number, got %r" % (weight,))
        if weight < 0:
            raise ValueError("weight must be >= 0, got %r" % (weight,))

        weighted_sum += value * weight
        total_weight += weight

    if count == 0:
        raise ValueError("mean requires at least one (value, weight) pair")
    if total_weight == 0:
        raise ValueError("total weight must be > 0, got 0")

    return weighted_sum / total_weight
