"""Extract plain text from HTML using only the Python standard library."""

from html.parser import HTMLParser


class _TextExtractor(HTMLParser):
    """HTML parser that collects visible text, skipping script/style blocks."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self._words = []
        self._skip_depth = 0
        self._ignored_tags = {"script", "style"}

    def handle_starttag(self, tag, attrs):
        if tag in self._ignored_tags:
            self._skip_depth += 1

    def handle_startendtag(self, tag, attrs):
        # Self-closing tags (e.g. <script/>) open no content to skip.
        pass

    def handle_endtag(self, tag):
        if tag in self._ignored_tags and self._skip_depth > 0:
            self._skip_depth -= 1

    def handle_data(self, data):
        if self._skip_depth > 0:
            return
        self._words.extend(data.split())


def text(html):
    """Return the visible text of *html* with words joined by single spaces.

    - Content of <script> and <style> elements is ignored entirely.
    - HTML entities are decoded (convert_charrefs=True).
    - Remaining text nodes are split on whitespace and joined with one space.
    """
    extractor = _TextExtractor()
    extractor.feed(html)
    extractor.close()
    return " ".join(extractor._words)
