"""Pure path validation for archive member names (no filesystem access)."""

NUL = "\x00"


def safe_member(name):
    """Return True if *name* is a safe relative archive path, else False.

    Rejected:
      - non-strings and empty strings
      - NUL characters
      - backslashes (Windows path separators are not safe)
      - absolute paths (leading '/')
      - a first component ending in a colon (Windows drive-like, e.g. 'C:')
      - any component that is exactly '..'

    Allowed:
      - '.' components and repeated forward slashes
    """
    if not isinstance(name, str):
        return False
    if name == "":
        return False
    if NUL in name:
        return False
    if "\\" in name:
        return False
    if name.startswith("/"):
        return False  # absolute path

    components = [c for c in name.split("/") if c != ""]  # repeated '/' ok
    if not components:
        return False
    if components[0].endswith(":"):
        return False  # drive-like first component
    for c in components:
        if c == "..":
            return False
    return True
