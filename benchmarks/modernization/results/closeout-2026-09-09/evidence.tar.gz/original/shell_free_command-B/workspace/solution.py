"""Run a subprocess directly (no shell) and capture its output.

Standard library only.
"""

import subprocess


def run(args, cwd=None):
    """Execute ``args`` directly with ``shell=False`` in ``cwd``.

    Args:
        args: Nonempty list of strings forming the command (argv[0] is the
            executable).
        cwd: Working directory for the child process.

    Returns:
        dict with keys:
            code:   int exit status (returned as-is; nonzero is not raised)
            stdout: str decoded with errors="replace"
            stderr: str decoded with errors="replace"

    Raises:
        ValueError: if ``args`` is empty.
        FileNotFoundError, PermissionError, OSError: propagated from
            subprocess when the executable cannot be launched.
    """
    if not args:
        raise ValueError("args must be a nonempty list of strings")

    completed = subprocess.run(
        list(args),
        shell=False,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )

    return {
        "code": completed.returncode,
        "stdout": completed.stdout.decode("utf-8", errors="replace"),
        "stderr": completed.stderr.decode("utf-8", errors="replace"),
    }
