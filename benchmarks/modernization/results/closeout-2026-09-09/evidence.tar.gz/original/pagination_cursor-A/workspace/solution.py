"""Cursor-based pagination over a list of row dicts.

Rows are dicts with a distinct integer ``id`` key, in arbitrary order.
Only the Python standard library is used.
"""


def page(rows, after, limit):
    """Select up to ``limit`` rows whose ids are strictly greater than ``after``.

    Parameters
    ----------
    rows : list of dict
        Rows with a distinct integer ``id`` key. Not mutated.
    after : int or None
        Cursor; select ids strictly greater than ``after``. ``None`` selects all.
    limit : int
        Maximum number of rows to return. Must be positive.

    Returns
    -------
    (selected, next_cursor) : tuple[list of dict, int or None]
        ``selected`` is the page of rows sorted by ascending id.
        ``next_cursor`` is the id of the last selected row if more eligible
        rows remain, otherwise ``None``.

    Raises
    ------
    ValueError
        If ``limit`` is not a positive integer.
    """
    if not isinstance(limit, int) or isinstance(limit, bool) or limit <= 0:
        raise ValueError("limit must be a positive integer")

    # Eligible ids, ascending; input is never mutated.
    eligible = sorted(row["id"] for row in rows if after is None or row["id"] > after)

    selected_ids = eligible[:limit]
    selected = [row for row in sorted(rows, key=lambda r: r["id"]) if row["id"] in set(selected_ids)]

    # More eligible rows remain beyond this page?
    if len(eligible) > limit:
        next_cursor = selected_ids[-1]
    else:
        next_cursor = None

    return selected, next_cursor
