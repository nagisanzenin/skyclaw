import codecs
import json
from typing import Iterable, List


def parse_chunks(chunks: Iterable[bytes]) -> List:
    """Parse an iterable of byte chunks comprising UTF-8 JSON Lines.

    Decodes incrementally across arbitrary byte boundaries, ignores blank
    lines, and parses a final record even if it is not newline-terminated.

    Raises ValueError for malformed JSON; malformed UTF-8 raises
    UnicodeDecodeError (a subclass of ValueError).
    """
    decoder = codecs.getincrementaldecoder("utf-8")(errors="strict")
    values: List = []
    buffer = ""  # text of the current, not-yet-terminated line

    for chunk in chunks:
        if chunk is None:
            continue
        # Incremental decode; raises UnicodeDecodeError on malformed UTF-8
        # (invalid even across chunk boundaries is caught here).
        text = decoder.decode(chunk)
        if not text:
            continue
        buffer += text
        # Process every complete line; keep the trailing partial in buffer.
        *lines, buffer = buffer.split("\n")
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            values.append(json.loads(stripped))

    # Finalize the decoder (surrogates/unfinished sequences would error here).
    buffer += decoder.decode(b"", final=True)

    # Final non-newline-terminated record, if any.
    stripped = buffer.strip()
    if stripped:
        values.append(json.loads(stripped))

    return values
