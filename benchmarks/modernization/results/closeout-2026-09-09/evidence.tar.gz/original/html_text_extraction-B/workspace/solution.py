"""Extract visible text from HTML using only the standard library."""

from html import unescape
from html.parser import HTMLParser

_SKIP_TAGS = frozenset({"script", "style"})


class _TextExtractor(HTMLParser):
    """Collect whitespace-separated words from text nodes, skipping script/style."""

    def __init__(self):
        # convert_charrefs=True (default) already decodes entities in data,
        # but we unescape again defensively in case it is disabled.
        super().__init__(convert_charrefs=True)
        self._words = []
        self._skip_depth = 0

    def handle_starttag(self, tag, attrs):
        if tag.lower() in _SKIP_TAGS:
            self._skip_depth += 1

    def handle_startendtag(self, tag, attrs):
        # Self-closing <script/> / <style/> opens and closes: no content skipped.
        pass

    def handle_endtag(self, tag):
        if tag.lower() in _SKIP_TAGS and self._skip_depth > 0:
            self._skip_depth -= 1

    def handle_data(self, data):
        if self._skip_depth == 0 and data:
            self._words.extend(unescape(data).split())

    def result(self):
        return " ".join(self._words)


def text(html):
    """Return the visible text of *html*: script/style content removed,
    entities decoded, remaining words joined by a single space."""
    extractor = _TextExtractor()
    extractor.feed(html)
    extractor.close()
    return extractor.result()
