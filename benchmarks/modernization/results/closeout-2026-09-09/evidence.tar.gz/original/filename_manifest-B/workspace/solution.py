"""Recursive manifest of regular files under a directory tree.

Public API:
    manifest(root) -> sorted list of relative POSIX-style paths (str)
"""

import os

__all__ = ["manifest"]


def manifest(root):
    """Recursively return sorted relative POSIX paths of regular files under *root*.

    - Regular files only: symlink files and symlink directories are never
      followed nor included.
    - Hidden entries (dot-files) are included.
    - Directories themselves are omitted from the result.
    - Paths are relative to *root* and always use '/' as the separator.

    Uses only the Python standard library.
    """
    root = os.fspath(root)
    results = []

    def recurse(dir_path, rel_prefix):
        with os.scandir(dir_path) as it:
            entries = list(it)
        for entry in entries:
            rel = entry.name if rel_prefix == "" else rel_prefix + "/" + entry.name
            # Never follow or include symlinks (files or directories).
            if entry.is_symlink():
                continue
            if entry.is_dir(follow_symlinks=False):
                recurse(entry.path, rel)
            elif entry.is_file(follow_symlinks=False):
                results.append(rel)

    recurse(root, "")
    return sorted(results)
