"""Cursor-based pagination over unsorted row dicts."""

from typing import Any, Dict, List, Optional, Tuple


def page(
    rows: List[Dict[str, Any]],
    after: Optional[int],
    limit: int,
) -> Tuple[List[Dict[str, Any]], Optional[int]]:
    """Select rows with id strictly greater than ``after``, sorted by id.

    Returns ``(selected, next_cursor)``. ``next_cursor`` is the id of the
    last returned row only when further eligible rows remain, else ``None``.
    The input ``rows`` list is not mutated; the original row dicts are
    returned (not copies of their ids, not new dicts).
    """
    if not isinstance(limit, int) or isinstance(limit, bool) or limit <= 0:
        raise ValueError("limit must be a positive integer")

    # Filter by id, sort eligible ids ascending. Rows themselves untouched.
    eligible = sorted(
        (row for row in rows if after is None or row["id"] > after),
        key=lambda row: row["id"],
    )

    selected = eligible[:limit]
    if not selected:
        return [], None

    # More rows remain beyond this page only if eligible list is longer.
    next_cursor: Optional[int] = selected[-1]["id"] if len(eligible) > limit else None
    return selected, next_cursor
