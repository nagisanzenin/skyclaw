# Implement the requested API here.


def page(rows, after, limit):
    """Return (selected, next_cursor) using keyset pagination over rows.

    rows: iterable of dicts, each with a distinct integer "id" key (unsorted).
    after: cursor; only rows with id > after are eligible (None = all rows).
    limit: maximum number of rows to return; must be a positive integer.

    Returns (selected, next_cursor) where selected is a list of the original
    row dicts sorted by id ascending, and next_cursor is the id of the last
    selected row only if further eligible rows remain, else None.
    The input is not mutated.
    """
    if not isinstance(limit, int) or isinstance(limit, bool) or limit <= 0:
        raise ValueError("limit must be a positive integer")

    eligible = [row for row in rows if after is None or row["id"] > after]
    eligible.sort(key=lambda row: row["id"])

    selected = eligible[:limit]
    if len(eligible) > limit:
        next_cursor = selected[-1]["id"]
    else:
        next_cursor = None
    return selected, next_cursor
